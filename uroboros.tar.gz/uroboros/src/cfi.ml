open Visit
open Type
open Batteries

open Ail_utils

type instr_update = SUB | INSERT

class cfi len =
(* A fine-grained CFI impelmentation.
 * policy:
 *    we can go similiar policy as HyperSafe(Okaland 2010)
 *    the MOST important thing by far is we want to do FINE-GRAINED policy!!
 *    theoretically, we want to build
 *    indirect control transfer target table for
 *    EACH call/jump and ICT target table for all the rets inside one function (each function, I mean)
 *    we must solve the issue come up with these two papers about coarse-grained CFI
 *    stitching the gadgets (USENIX 2014)
 *    out of control (Okaland 2014)
 *
 *  currently, in my design, CFG should process before reassemble plguin.
 *  see vinst's pattern match for details *
 * TODO list:
 *   1. runnable transform cfi code
 *   2. **dumy** policy check before call/jump; ret (always return true if empty table)
 *   3. **dumy** table of legal destination (empty table)
 *   4. (register) value set analysis
 *           mov *(%eax);
 *           mov *0x24(%esi);
 *           mov *(%ebx, %eax, 4);
 *           mov *base_addr(, %eax, 4);  (base_addr is a concrete value)
 *   5. update legal table, update policy
 *   6. experiment ....
 *    *)


 let dec_hex (s:int) : string =
            "0x"^(Printf.sprintf "%X" s)

  (* and mem_addr = ref 0xdeadbeef in *)
  and mem_addr = ref 0xdead in

    object(self)

    (* The DynArray in OCaml Batteries provide the `insert` function, however,
     * it is just too slow ...
     * I inplemented a much more efficient algorithm myself *)

        (* val mutable instrs_array = DynArray.make 1 *)

        val mutable instrs_update = []
        val mutable locs_update = []
        val mutable next_instr =
          SingleInstr (CommonOP (Other NOP), {loc_label = "";
                                              loc_addr = 0; loc_visible=true;}, None)
        val mutable cfi_cg_tbl = Hashtbl.create 500
        (* each function has one entry in this table *)
        val mutable cfi_ret_tbl = Hashtbl.create 30

        inherit ailVisitor

        method insert_instrs i l =
          instrs_update <- (i, l, INSERT)::instrs_update

        method sub_instrs i l =
          instrs_update <- (i, l, SUB)::instrs_update

        method update_instrs instrs =
          let same loc1 loc2 =
            loc1.loc_addr = loc2.loc_addr in
          let rec help l_u l =
            match (l_u, l) with
            | (h_u::t_u, h::t) ->
              begin
                let (i, loc1, ty) = h_u
                and loc2 = get_loc h in
                  if same loc1 loc2 then
                    match ty with
                    | SUB ->
                      (help t_u (i::t))
                    | INSERT ->
                      h::(help t_u (i::t))
                  else
                    h::(help l_u t)
              end
            | ([], l') -> l'
            | (l_u, l) -> failwith "error in update_instrs"
          in
            help instrs_update instrs

        method add_label i =
          let l = get_loc i in
            let l' = {loc_label = l.loc_label^(dec_hex l.loc_addr);
                      loc_addr = l.loc_addr; loc_visible = true;
                     } in
              set_loc i l'


        method add_label_2 i l =
          let l' = get_loc i in
            let l1 = {loc_label = "S_"^(dec_hex l.loc_addr)^"_next : ";
                      loc_addr = l'.loc_addr; loc_visible = true;} in
              (* set_loc i l1 *)
              locs_update <- l1::locs_update


        method func_info l =
            let rec help funcs =
                match funcs with
                | h::[] ->
                    begin
                        if l.loc_addr >= h.func_begin_addr && l.loc_addr < h.func_end_addr then
                            h
                        else
                          (
                            failwith ((dec_hex (l.loc_addr))^"can't find coresponding functions")
                          )
                    end
                | h::t ->
                    begin
                        if l.loc_addr >= h.func_begin_addr && l.loc_addr < h.func_end_addr then
                            h
                        else help t
                    end
                | _ ->
                      (
                            failwith ((dec_hex (l.loc_addr))^"can't find coresponding functions")
                      )
            in
                help funcs

        (* ret checking insert
         *
         *       ret
         *
         * is instrumented as:
         *
         *       pop %ebx
         *       and $0x3f, %ebx
         *       mov RT_pmap_read(,%ebx,4), %ebx
         *       jmp *%ebx
         *
         *  see HyperSafe (Okaland 2010) for more details
         *
         *)
        (* correct way to assign register: generally, without inter-procedure live analysis, we
         * just can not be sure which register is dead, however, relying on x86 calling convention, we can
         * be sure that %ebx would be retored in caller side, which means it is safe to use %ebx in direct jump here
         *)


        method update_ret l =
          try
            let f = self#func_info l in
            if Hashtbl.mem cfi_ret_tbl f.func_name then
              begin
              let rt_pmap_read = Hashtbl.find cfi_ret_tbl f.func_name in
              let rt_pmap_read' = "S_"^(dec_hex rt_pmap_read) in
              let i0 = SingleInstr (CommonOP (Other NOP), l, None)
              and i1 = DoubleInstr (StackOP POP, Reg (CommonReg EBX), l, None)
              and i2 = TripleInstr (CommonOP (Logic AND), Reg (CommonReg EBX), Const (Normal 0x3f), l, None)
              and i3 = TripleInstr (CommonOP (Assign MOV), Reg (CommonReg EBX),
                        Ptr (JmpTable_PLUS_S (rt_pmap_read', CommonReg EBX, 4)), l, None)
              and i4 = DoubleInstr (ControlOP (Jump JMP),Symbol (StarDes (Reg (CommonReg EBX))), l, None) in
                self#sub_instrs i0 l;
                self#insert_instrs i1 l;
                self#insert_instrs i2 l;
                self#insert_instrs i3 l;
                self#insert_instrs i4 l;
                ()
              end
            else ()
          with
          | _ -> print_string "error in update_ret";

         (* direct control flow transfer index insert
         *
         *      call pmap_read
         *
         * is instrumented as:
         *
         *       push $index
         *       jmp pmap_read
         *
         *  see HyperSafe (Okaland 2010) for more details
         *
         *)

        method update_direct_ct e l =
          try
            if Hashtbl.mem cfi_cg_tbl l.loc_addr then
              let pmap_index = Hashtbl.find cfi_cg_tbl l.loc_addr in
              let i0 = SingleInstr (CommonOP (Other NOP), l, None)
              and i1 = DoubleInstr (StackOP PUSH, Const (Normal (pmap_index-1)), l, None)
              and i2 = DoubleInstr (ControlOP (Jump JMP), e, l, None) in
                self#add_label_2 next_instr l;
                self#sub_instrs i0 l;
                self#insert_instrs i1 l;
                self#insert_instrs i2 l;
                (* self#sub_instrs ni (get_loc ni); *)
                ()
            else ()
          with
          | _ ->
            (* not found doesn't indicate errors, some of the
             * control flow transfers are not recorded;
             * see this issue for details
             *    https://github.com/computereasy/AIL/issues/8
             * *)
            print_string ("not found in update_direct_ct"^(dec_hex l.loc_addr));
            ()

         (* indirect control flow transfer index insert
         *
         *      call *%eax
         *
         * is instrumented as:
         *
         *       and $0x3f, %eax
         *       mov RT_pmap_read(,%eax,8), %eax
         *       push %eax
         *       jmp *%eax
         *
         *  see HyperSafe (Okaland 2010) for more details
         *
         *)

        method update_indirect_ct l =
          (* let rt_pmap_read = 0xdeadbeef in *)
          let rt_pmap_read = 0xdead in
          let i0 = SingleInstr (CommonOP (Other NOP), l, None)
          and i1 = TripleInstr (CommonOP (Logic AND), Reg (CommonReg EAX), Const (Point 0x3f), l, None)
          and i2 = TripleInstr (CommonOP (Assign MOV), Reg (CommonReg EAX),
                      Ptr (JmpTable_PLUS (rt_pmap_read, CommonReg EAX, 8)), l, None)
          and i3 = DoubleInstr (StackOP PUSH, Reg (CommonReg EAX), l, None)
          and i4 = DoubleInstr (ControlOP (Jump JMP), Symbol (StarDes (Reg (CommonReg EAX))), l, None) in
            self#sub_instrs i0 l;
            self#insert_instrs i1 l;
            self#insert_instrs i2 l;
            self#insert_instrs i3 l;
            self#insert_instrs i4 l;
            ()

        method cfi_vinst i =
          (* check whether is control flow transfer opcodes *)
          let is_dct op e =
            let is_ct =
              match op with
              | ControlOP c ->
                begin
                  match c with
                    | Jump _ -> true (* jump ops *)
                    | CALL -> true (* call *)
                    | _ -> false
                end
              | _ -> false in
            if is_ct = false then false
            else
              match e with
               | Symbol s ->
                  begin
                    match s with
                     | JumpDes _ -> true
                     | CallDes f when f.is_lib = false -> true
                     | _ -> false
                   end
               | _ -> false
          and is_idct op e =
            let is_ct =
              match op with
              | ControlOP c ->
                begin
                  match c with
                    | Jump _ -> true (* jump ops *)
                    | CALL -> true (* call *)
                    | _ -> false
                end
              | _ -> false in
            if is_ct = false then false
            else
              match e with
                (* jmp *0x80509e4(,%eax,4);
                 * call *(%eax);
                 * ...
                 *)
               | Symbol s ->
                  begin
                    match s with
                     | StarDes _ -> true
                     | _ -> false
                   end
               | _ -> false
          and is_ret op =
            match op with
            | ControlOP c ->
              begin
                match c with
                  | RET | RETN -> true
                  | _ -> false
              end
            | _ -> false in
          match i with
              | SingleInstr (p, l, _) when (is_ret p) ->
                self#update_ret l
              | DoubleInstr (p, e, l, _) when (is_dct p e) ->
                self#update_direct_ct e l
              | DoubleInstr (p, e, l, _) when (is_idct p e) ->
                (* self#update_indirect_ct l *)
                ()
              | _ -> ()

        method visit (instrs: instr list) =
            let rec help l =
              match l with
              | h1::h2::t ->
                    next_instr <- h2;
                    self#cfi_vinst h1;
                    help (h2::t)
              | h::[] -> self#cfi_vinst h
              | _ -> failwith " error in visit " in
              help instrs;
              instrs_update <- List.rev instrs_update;
              let instrs' = self#update_instrs instrs in
                self#update_locs instrs'
              (* self#update_instrs instrs *)

        method update_locs instrs =
          locs_update <- List.rev locs_update;
          let rec help il ll =
            match (il, ll) with
              | (ih::it, lh::lt) ->
                  begin
                    let lo = get_loc ih in
                      if lo.loc_addr = lh.loc_addr then
                        begin
                          (* print_string lh.loc_label; *)
                          (* print_string "\n"; *)
                          let ih' = set_loc ih
                            {loc_label = lo.loc_label^"\n"^lh.loc_label;
                               loc_addr = lo.loc_addr;loc_visible=true;} in
                            ih'::(help it lt)
                        end
                      else
                        (
                          (* print_string (dec_hex lh.loc_addr); *)
                          (* print_string "\n"; *)
                          ih::(help it ll)
                        )
                  end
              | (il', []) -> il'
              | ([], ll') -> failwith "error in update_locs" in
                help instrs locs_update

        method print_cg_tbl cfi_cg_tbl =
          let help addr c =
            print_string (dec_hex addr);
            print_int c;
            print_string "\n" in
            Hashtbl.iter help cfi_cg_tbl

        (* this function transform cfi_table into a new table with index*)
        method set_cfi_graph cfi_tbl =
          self#create_cg_tbl cfi_tbl;
          self#create_ret_tbl cfi_tbl

        method create_cg_tbl cfi_tbl =
          let help f addrs  =
            (*let dumy = f = "func" in *)
            let count = ref 1 in
              List.iter (fun addr ->
                          Hashtbl.replace cfi_cg_tbl addr !count;
                          count := !count + 1
                         ) addrs in
            Hashtbl.iter help cfi_tbl

        (* TODO : better solution on get next memory address *)
        method get_next_mem =
          let current_addr = !mem_addr in
            mem_addr := !mem_addr + 256;
            current_addr

        method dump_mem con addr =
          let oc = open_out_gen [Open_append; Open_creat] 0o666 "final.s" in
            Printf.fprintf oc "S_%s :\n%s\n" (dec_hex addr) con;
            close_out oc

        method create_tbl_mem f addrs =
          let help acc addr =
            acc^".long S_"^(dec_hex addr)^"_next\n" in
            let content = List.fold_left help "" addrs
            and mem_addr' = self#get_next_mem in
              self#dump_mem content mem_addr';
              mem_addr'

        method create_ret_tbl cfi_tbl =
          let help f addrs =
            let dumy = f = "func" in
            let mem_addr' = self#create_tbl_mem f addrs in
              Hashtbl.replace cfi_ret_tbl f mem_addr';
          in
            Hashtbl.iter help cfi_tbl

            (* self#print_cg_tbl cfi_cg_tbl *)


    end
