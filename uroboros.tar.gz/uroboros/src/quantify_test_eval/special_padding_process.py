# here is the wired thing, in modified linker/assembler produced assembly code, 
# we can find wired "embedded C code", start with MACRO #APP and end with MACRO #NO_APP
# this situation can be found in perlbench final.perlbench.gcc.s


import sys, os

funcs = []

with open("func_list") as f:
    funcs = f.readlines()

def help(f):
	f = f.strip()
	f = f.split()[1][1:-2]
	return f

funcs = map(help, funcs)

lines = []

fn = sys.argv[1]

with open(fn) as f:
    lines = f.readlines()

in_detect = False
fname = ""
index = 0

for i in range(0,len(lines)):
	l = lines[i]
	items = l.strip().split()
	if len(items) == 2 and items[0] == "jmp" and items[1] in funcs:
		in_detect = True
		fname = items[1] + ":"
		index = i
	elif "nop" == l.strip() and in_detect == True:
		in_detect = True
	elif "S_0x" in l.strip() and in_detect == True:
		in_detect = True
	elif in_detect == True and fname == l.strip():
		print fname 
		print l
		lines[index] = ""
		in_detect = False
	else:
		in_detect = False	
		
with open(fn+".new",'w') as f:
	f.writelines(lines)
