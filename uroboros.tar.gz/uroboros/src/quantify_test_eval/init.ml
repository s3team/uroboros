(* init : use GNU utils objdump to disassemble
 * initialize file info, section info, generate disassemble file*)

open Batteries

open Ail
open Ail_ir_mining

class ailInit =
    object (self) 

        method ailProcess (f : string)  =
            let processor = new ail f in
                (
                    processor#program_process
                )
    end

let main () =
    let f1 = Sys.argv.(1) 
    and f2 = Sys.argv.(2) in
      let init1 = new ailInit 
      and init2 = new ailInit in
        let ir1_tbl1 = init1#ailProcess f1
        and ir2_tbl2 = init2#ailProcess f2 in 
          let com = new ail_ir_mining in 
           let sym1_tbl = com#symbol_collect ir1_tbl1
           and sym2_tbl = com#symbol_collect ir2_tbl2 in 
            com#symbol_compare sym1_tbl sym2_tbl;
            ()

let () = main ()
