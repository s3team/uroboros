import sys, os

# fn1 is the compiler produced assembly code
fn1 = sys.argv[1]
# fn2 is the disassembler produced assembly code
fn2 = sys.argv[2]


blk = ['.cfi_', '.align', '.p2align', '.globl', '.comm', '.ident', '.long',
		'.local', '.data', '.zero','.bss']

# parse instruction like 8B150400 0000                                   movl    dummy+4, %edx
# into (8B, 6, is_jmpop)
# if len(l) < 36, just let it crash
def parse1(l):
    sub = l[0:35].strip()
    items = sub.split()
    if len(items) < 2:
        return ("0", "", True)
    op = items[2][0:2]  # get the opcode
    l1 = sum(map(lambda item : len(item), items))/2 # get the length of instructions
    sub1 = l[35:].strip()
    print '******************'
    #print l
    #print sub1
    #print op
    print '******************'
    if op == '89' and l1 == 9 and ".p2align" in l:
	l1 = 2
    if op == 'EB' and l1 == 15 and ".p2align" in l:
	l1 = 2
    if 'j' == sub1[0]:
	return (op, l1, True)
    else:
	return (op, l1, False)

def parse2(l):
    if len(l) < 30:
        # empty instruction
        return ('0',"",True)
    sub = l[0:30].strip()
    items = sub.split()
    op = items[1] # obtain the opcode
    l1 = sum(map(lambda item : len(item), items))/2 # get the length of instructions
    sub1 = l[30:].strip()
    #print l
    #print sub1
    if ":" in sub1: # jump label
    	sub1 = sub1.split(':')[1]
    if 'j' == sub1[0]:
    	return (op, l1, True)
    else:
	return (op, l1, False)

# here is one possiblity,
# 6690 .p2align 3
# as we can not eliminate 6690 in disassembler produced assembly code,
# we have to consider it as one instruction and do the comparation

def check_opcode(l):
    items = l.strip().split()
    if len(items) >=2:
        try:
            int(items[0],16)
            t = items[0][0:2]
            if t == "90" or t == "8D":
                # 90 would be translated into NOP in disassembler produced assembly code
                return False
            else:
                return True
        except ValueError:
            return False
    else:
        return False

fn1_instr = []
is_text_sec = False
def read_file1(l):
    global is_text_sec
    if ".section" in l and ".text" not in l:
    	is_text_sec = False
    	return
    if ".data" in l or ".rodata" in l or ".bss" in l:
    	is_text_sec = False
    elif ".text" in l:
    	is_text_sec = True
    elif is_text_sec == False:
    	return
    elif any(item in l for item in blk) and check_opcode(l) == False:  #
    	return
    else:
    	items = l.split()
    	if len(items) == 1:
            label = items[0].strip()
            if label[-1] == ':' and label[0:2] != '.L':
    		fn = label[:-1]
    		# function begin
                pass
            else:
                print "expcetion 1 : "+l
        else:
            l = l.strip()
            if l == "" or "nop" in items or "lea 0x0(%esi),%esi" in l:
    		return
            else:
    		fn1_instr.append(parse1(l))

fn2_instr = []

def read_file2(l):
    global in_func
    global func_name
    global funcs_list
    global is_text_sec
    if ".section" in l and ".text" not in l:
    	is_text_sec = False
    	return
    elif ".data" in l or ".rodata" in l or ".bss" in l:
    	is_text_sec = False
    	return
    elif ".text" in l:
    	is_text_sec = True
    	return
    elif is_text_sec == False:
    	return
    else:
    	items = l.split()
    	if len(items) == 1:
            label = items[0].strip()
            if label[-1] == ':' and label[0:2] != '.L':
    		# function begin
                return
            else:
                print "expcetion 1 : "+l
    	l = l.strip()
    	if l == "" or "nop" in items or "nop;" in l or "lea 0x0(%esi),%esi" in l or "lea 0x0(%edi),%edi" in l:
            return
    	if l[0] == '?':
            l = ' ' + l[1:]
    	fn2_instr.append(parse2(l))


lines = []
with open(fn1) as f:
    lines = f.readlines()
map(lambda l : read_file1(l), lines)


lines = []
with open(fn2) as f:
    lines = f.readlines()
map(lambda l : read_file2(l), lines)


def do_compare(o1, o2):
    (opcode1, len1, is_jmpop1) = o1
    (opcode2, len2, is_jmpop2) = o2
    if opcode1 != opcode2.upper():
        if is_jmpop1 == False or is_jmpop2 == False:
            return False
    else:
    	if len1 == len2:
            return True
    	else:
            return False

fn1_instr = filter(lambda l : l[0] != "0", fn1_instr)

l1 = len(fn1_instr)
l2 = len(fn2_instr)

l = min(l1,l2)

print "compiler generated assembly code has " + str(l1) + " lines of code"
print "disassembler generated assembly code has " + str(l2) + " lines of code"

for i in range(l):
    o1 = fn1_instr[i]
    o2 = fn2_instr[i]
    r = do_compare(o1,o2)
    print str(o1) + " " + str(o2) + " " + str(r)

#print fn1_instr
#print fn2_instr
