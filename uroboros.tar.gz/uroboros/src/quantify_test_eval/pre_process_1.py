import sys

lines = []
with open(sys.argv[1]) as f:
    lines = f.readlines()

def pre_process(l):
	if ";" in l:
		if "nop;nop;nop;nop;nop;nop;nop;" in l:
			l = "nop"
	elif "repnz scas %es:(%edi),%al" in l:
		l = l.replace("repnz scas %es:(%edi),%al","repnz scasb")
	elif "repz cmpsb %es:(%edi),%ds:(%esi)" in l:
		l = l.replace("repz cmpsb %es:(%edi),%ds:(%esi)","repz cmpsb")
	elif "rep stos %eax,%es:(%edi)" in l:
		l = l.replace("rep stos %eax,%es:(%edi)","rep stosl")
	return l
lines = map(lambda l : pre_process(l), lines)

with open(sys.argv[1], 'w') as f:
    f.writelines(lines)
