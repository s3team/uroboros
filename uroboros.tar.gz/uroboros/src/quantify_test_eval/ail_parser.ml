open Type
open Parser
open Pp_print

class ailParser =
    object (self)
        val mutable instrs : instr list = []
        val mutable funcs : func list = []
        val mutable secs: section list = []

        method process_instrs (l : string list) =
            let cat_tail s =
              match s with
               | [] -> "" 
               | h::t -> String.trim (String.concat ":" t) in
            let p = new parse in
            let split = Str.split (Str.regexp_string ":") in
            let l' = List.filter (
                                  fun i ->
                                    let items = split i in
                                    let len = List.length items in
                                     len > 0 ) l in
            let help i =
              let items = split i in
              (* print_string (i^"\n"); *)
              let loc = List.nth items 0 in
              let instr = cat_tail items
                in
                  instrs <- (p#parse_instr instr loc)::instrs
              in
                List.iter help l';
                funcs <- p#get_funclist

        method p_instrs =
          List.iter (fun i -> let is = pp_print_instr i in print_string is) instrs

        method get_ir =
            List.rev instrs

        method get_instrs_len =
            List.length instrs

    end
