import sys, os

funcs = []

with open("func_list") as f:
    funcs = f.readlines()

def help(f):
	f = f.strip()
	f = f.split()[1][1:-2]
	return f

funcs = map(help, funcs)

with open("func_list_new", 'w') as f:
    map(lambda l : f.write(l+"\n"), funcs)

asm = sys.argv[1]

funcs_list = {}

in_func = False
func_name = ""

with open(asm) as f:
    lines = f.readlines()

# paune empty line; nop
def help1(l):
	global in_func
	global func_name
	global funcs_list
	l = l.strip()
	if l.endswith(":") and ".L" not in l:   # function name
		if l[:-1] in funcs: # found function
			func_name = l[:-1]
			funcs_list[func_name] = []
			in_func = True
	elif in_func == True:
		if l == "":
			pass
		else:
			items = l.split()
			if "nop;nop;nop;nop;nop;nop;nop;" in l:
				l = l.replace("nop;nop;nop;nop;nop;nop;nop;", "nop")
			if "repnz scas %es:(%edi),%al" in l:
				l = l.replace("repnz scas %es:(%edi),%al","repnz scasb")
			if "repz cmpsb %es:(%edi),%ds:(%esi)" in l:
				l = l.replace("repz cmpsb %es:(%edi),%ds:(%esi)","repz cmpsb")
			if "rep stos %eax,%es:(%edi)" in l:
				l = l.replace("rep stos %eax,%es:(%edi)","rep stosl")
			if "%es:(%edi)" in l and "stos" in l:
				l = "stosw"	
			if "rep movsl" in l:
				l = "rep movsl"
			if "gs:" in l:
				l = l.replace("gs:", "") # screw it!
			if ":" in l:
				if len(l.split(':')) == 2:
					l = l.replace(":",":\nZZZ:")
					funcs_list[func_name].append(l+"\n")
					return
				else:
					print "error :" + l
			funcs_list[func_name].append("ZZZ:" + l+"\n")
	else: # probably data
		pass
map(lambda l: help1(l), lines)

os.system('rm -rf '+asm+"_funcs")
os.system('mkdir '+asm+"_funcs")

os.chdir(asm+"_funcs")

for fn, content in funcs_list.items():
	os.system('touch '+fn)

	with open(fn, 'w') as f:
		f.writelines(content)
