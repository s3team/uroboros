import sys, os

lines = []

fn = sys.argv[1]

with open(fn) as f:
    lines = f.readlines()

for i in range(0, len(lines)):
	l = lines[i]
	l1 = l.strip()
	if l1.endswith(':'):
		if i < len(lines) - 1:
			ln = lines[i+1]
			lines[i+1] = ln.replace('ZZZ', l1[:-1])
		lines[i] = ""

def help(l):
	l = l.replace(' ,', ',')
	items = l.split()
	l = " ".join(items)
	return l + '\n'

lines = map(lambda l : help(l), lines)
lines = filter(lambda l : l.strip() != "" and l.strip() != "ZZZ:", lines)

with open(fn, 'w') as f:
	f.writelines(lines)
