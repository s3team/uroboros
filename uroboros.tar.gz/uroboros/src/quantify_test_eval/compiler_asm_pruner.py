import sys, os, re

lines = []

fn = sys.argv[1]

with open(fn) as f:
    lines = f.readlines()

is_text_sec = False

blk = ['.cfi_', '.align', '.p2align', '.globl', '.comm', '.ident', '.long', 
		'.local', '.data', '.zero','.bss']

def help(l):
	global is_text_sec
	if ".section" in l and ".text" not in l:
		is_text_sec = False
		return ""
	elif ".text" in l:
		is_text_sec = True
		return ""
	elif is_text_sec == False:
		return ""
	elif any(item in l for item in blk):  #
		return ""
	elif ".string" in l or ".byte" in l or ".long" in l:
		return ""
	else:
		pat = "(\(%[abcdesxip]+,%[abcdesxip]+\))"
		matched = re.search(pat, l)
		if matched:
			t = matched.group(1)[:-1]
			l = l.replace(t,t+",1")
			if "movb" in l:
				l = l.replace('movb', 'mov')
			if 'leal' in l:
				l = l.replace('leal', 'lea')
		return l

lines = map(lambda l : help(l), lines)

with open(fn+".mod", 'w') as f:
	f.writelines(lines)
