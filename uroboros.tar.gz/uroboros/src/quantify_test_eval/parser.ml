open Lex
open Type
open Batteries
open Printf

exception ParseError

type stack_type = Op of op
                  | Exp of exp
                  | Loc of loc

class parse =

let count = ref 0 in

let call_des = ref false in

let commonreg_symb = function
  | "eax" -> EAX | "ebx" -> EBX | "ecx" -> ECX
  | "edx" -> EDX | "edi" -> EDI | "esi" -> ESI
  | "ax" -> AX | "bx" -> BX | "cx" -> CX
  | "dx" -> DX | "al" -> AL | "bl" -> BL
  | "cl" -> CL | "dl" -> DL | "ah" -> AH
  | "bh" -> BH | "ch" -> CH | "dh" -> DH
  | _ -> raise ParseError

and stackreg_symb = function
  | "esp" -> ESP | "ebp" -> EBP
  | _ -> raise ParseError
and otherreg_symb = function
  | "eiz*1" -> EIZ
  | _ -> raise ParseError
and pcreg_symb = function
  | "eip" -> EIP
  | _ -> raise ParseError in

let reg_symb r =
          let r' = String.sub r 1 ((String.length r)-1) in
            try CommonReg (commonreg_symb r')
             with _ ->
             try StackReg (stackreg_symb r')
             with _ ->
             try PCReg (pcreg_symb r')
             with _ ->
             try OtherReg(otherreg_symb r')
             with _ -> raise ParseError

and loc_symb s =
  count := !count + 1;
  if String.exists s "ZZZ" then
    {loc_label="normal"; loc_addr=(!count);}
  else 
    {loc_label=s; loc_addr=(!count);}

and const_symb s =
  if s.[0] = '$' then
    let s' = String.sub s 1 ((String.length s)-1) in
    Normal (int_of_string s')
  else
    Point (int_of_string s)

and ptrtyp_symb = function
    | "QWORD" -> QWORD | "DWORD" -> DWORD
    | "WORD" -> WORD | "BYTE" -> BYTE | "TBYTE" -> BYTE
    | _ -> raise ParseError

and mathsymb_op = function
    | "+" -> MATHADD | "-" -> MATHSUB
    | _ -> raise ParseError in

let binptr_p_symb s =
  if String.contains s ',' then raise ParseError
  else let split = Str.split (Str.regexp_string "(") in
    let items = split s in
      let offset = List.nth items 0 in
        let s' = List.nth items 1 in
          let len = String.length s' in
          let r = String.sub s' 0 ((String.length s')-1) in
  (reg_symb r, int_of_string offset) in

let binptr_m_symb s =
  if String.contains s ',' then raise ParseError
  else let split = Str.split (Str.regexp_string "(") in
    let items = split s in
      let offset = List.nth items 0 in
        if offset.[0] <>'-' then raise ParseError
        else
          let len = String.length offset in
          let offset' = String.sub offset 1 (len-1)
          and s' = List.nth items 1 in
          let r = String.sub s' 0 ((String.length s')-1) in
  (reg_symb r, int_of_string offset')

and triptr_symb_1 = function s ->
  let op = if String.contains s '+' then "+" else "-"
  and len = String.length s in
  let s' = String.sub s 1 (len-2) in
  let split = Str.split (Str.regexp_string op)
  and split' = Str.split (Str.regexp_string "*") in
    let items = split s' in
      let item = List.nth items 0
      and addr = List.nth items 1 in
        let items' = split' item in
          let reg = List.nth items' 0
          and size = List.nth items' 1 in
       (reg_symb reg, int_of_string size, int_of_string addr, mathsymb_op op)

(* mov eax,DWORD PTR [ebx+eax*4] *)
and triptr_symb_2 = function s ->
  let op = if String.contains s '+' then "+" else "-"
  and len = String.length s in
  let s' = String.sub s 1 (len-2) in
  let split = Str.split (Str.regexp_string op)
  and split' = Str.split (Str.regexp_string "*") in
    let items = split s' in
      let reg1 = List.nth items 0
      and item = List.nth items 1 in
        let items' = split' item in
          let reg2 = List.nth items' 0
          and size = List.nth items' 1 in
       (reg_symb reg1, reg_symb reg2, int_of_string size, mathsymb_op op)

and fourptr_p_symb s =
  let split = Str.split (Str.regexp_string "(")
  and split' = Str.split (Str.regexp_string ",") in
    let items = split s in
      let offset = List.nth items 0
      and s' = List.nth items 1 in
        let l = String.length s' in
        let ss = String.sub s' 0 (l-1) in
        let items' = split' ss in
          if List.length items' <> 3 then raise ParseError
        else
          let r1 = List.nth items' 0
          and r2 = List.nth items' 1
          and off = List.nth items' 2 in
          (reg_symb r1, reg_symb r2, int_of_string off, int_of_string offset)

and fourptr_m_symb s =
  let split = Str.split (Str.regexp_string "(")
  and split' = Str.split (Str.regexp_string ",") in
    let items = split s in
      let offset = List.nth items 0 in
        if offset.[0] <>'-' then raise ParseError
        else
          let len = String.length offset in
          let offset' = String.sub offset 1 (len-1) in
          let s' = List.nth items 1 in
          let l = String.length s' in
          let ss = String.sub s' 0 (l-1) in
          let items' = split' ss in
            if List.length items' <> 3 then raise ParseError
          else
            let r1 = List.nth items' 0
            and r2 = List.nth items' 1
            and off = List.nth items' 2 in
          (reg_symb r1, reg_symb r2, int_of_string off, int_of_string offset')

and fourptr_symb s =
  let ls = String.length s in
  if s.[0] == '(' && s.[ls-1] == ')' then 
    begin
      let s' = String.sub s 1 (ls-2) in
      let split' = Str.split (Str.regexp_string ",") in
        let items = split' s' in
          if List.length items <> 3 then raise ParseError
            else
            (
              let r1 = List.nth items 0
              and r2 = List.nth items 1
              and off = List.nth items 2 in
              (reg_symb r1, reg_symb r2, int_of_string off)
            )
    end
  else
    raise ParseError


and remove_dollar_sign s' =
  let s = String.trim s' in
  if s.[0] = '$' then
    let l = String.length s in
      String.sub s 1 (l-1)
  else raise ParseError

and remove_bracket s' =
  let s = String.trim s' in
    let l = String.length s in
      if s.[0] = '(' && s.[l-1] = ')' then
        String.sub s 1 (l-2)
      else raise ParseError


and seg_symb = function
| "fs" -> FS | "gs" -> GS | "cs" -> CS
| "ss" -> SS | "ds" -> DS | "es" -> ES
| _ -> raise ParseError  in

let segref_symb s =
  let seg_list = ["%fs"; "%gs" ; "%cs" ; "%ss" ; "%ds" ; "%es"] in
  let list_has item =
    try ignore (List.find (fun i-> i = item) seg_list); true
    with Not_found -> false in
  if (String.contains s ':') then
    let split = Str.split (Str.regexp_string ":") in
      let items = split s in
        let se = List.nth items 0 in
    let has_seg = list_has se in
      if ((List.length items) = 2) && (has_seg = true) then
        let se' = remove_dollar_sign se in
          (seg_symb se', reg_symb (List.nth items 1))
      else
        raise ParseError
  else
    raise ParseError


and arithm_symb = function
  | "adc" -> ADC | "add" -> ADD | "xadd" -> XADD | "addl" -> ADDL
  | "sub" -> SUB | "mul" -> MUL | "imul" -> IMUL | "div" -> DIV
  | "idiv" -> IDIV | "idivl" -> IDIVL | "inc" -> INC | "incl" -> INCL
  | "dec" -> DEC | "neg" -> NEG | "negl" -> NEGL | "decl" -> DECL | "fdiv" -> FDIV
  | "sbb" -> SBB | "fadd" -> FADD | "fxch" -> FXCH | "subl" -> SUBL
  | "fucomip" -> FUCOMIP | "fucomi" -> FUCOMI | "bsr" -> BSR | "divl" -> DIVL
  | "adcl" -> ADCL | "mull" -> MULL | "addw" -> ADDW | "fmul" -> FMUL | "fmull" -> FMULL
  | "fmulp" -> FMULP | "fmuls" -> FMULS | "fadds" -> FADDS | "faddp" -> FADDP
  (*TODO : common case for fadd is that "fadd st, st(1), and currently st is considered as a label..." *)
  | "subw" -> SUBW | "imull" -> IMULL | "faddl" -> FADDL | "bswap" -> BSWAP
  | "fdivl" -> FDIVL | "addb" -> ADDB | "subb" -> SUBB | "sbbl" -> SBBL
  | "fdivr" -> FDIVR | "fabs" -> FABS | "fsqrt" -> FSQRT | "fdivrs" -> FDIVRS
  | "frndint" -> FRNDINT | "fdivrl" -> FDIVRL | "fprem" -> FPREM
  | _ -> raise ParseError
and logicop_symb = function
  | "and" -> AND | "andb" -> ANDB | "or" -> OR | "xor" -> XOR | "xorw" -> XORW | "not" -> NOT
  | "notl" -> NOTL | "andl" -> ANDL | "orw" -> ORW | "notb" -> NOTB | "notw" -> NOTW
  | "xorb" -> XORB | "xorl" -> XORL | "sahf" -> SAHF | "andw" -> ANDW
  | _ -> raise ParseError
and rolop_symb = function
  | "rol" -> ROL | "shl" -> SHL | "shr" -> SHR | "shrl" -> SHRL
  | "shld" -> SHLD | "shrd" -> SHRD | "roll" -> ROLL | "shrb" -> SHRB
  | "sal" -> SAL | "sall" -> SALL | "sar" -> SAR | "shll" -> SHLL | "shlb" -> SHLB
  | "sarl" -> SARL | "ror" -> ROR  | "rol" -> ROL | "rorl" -> RORL
  | "rolw" -> ROLW | "shlw" -> SHLW | "sarw" -> SARW | "shrw" -> SHRW | "sarb" -> SARB
  | _ -> raise ParseError
and assignop_symb = function
  | "mov" -> MOV | "xchg" -> XCHG | "lea" -> LEA | "leal" -> LEAL | "movsx" -> MOVSX | "fstpl" -> FSTPL
  | "movzx" -> MOVZX | "fld" -> FLD | "fstp" -> FSTP | "movl" -> MOVL | "fldl" -> FLDL
  | "cmovae" -> CMOVAE | "cmove" -> CMOVE | "cmovne" -> CMOVNE | "cmovbe" -> CMOVBE
  | "cmovb" -> CMOVB | "cmovs" -> CMOVS | "cmova" -> CMOVA | "cmovns" -> CMOVNS
  | "movb" -> MOVB | "movsbl" -> MOVSBL | "movsbw" -> MOVSBW | "fldt" -> FLDT
  | "fstpt" -> FSTPT | "fstps" -> FSTPS | "fsts" -> FSTS
  | "orl" -> ORL | "orb" -> ORB | "fnstcw" -> FNSTCW | "fldcw" -> FLDCW
  | "fnstsw" -> FNSTSW | "fldz" -> FLDZ | "fld1" -> FLD1 | "fdivp" -> FDIVP
  | "repe" -> REPE | "repz" -> REPZ | "movzbl" -> MOVZBL | "movw" -> MOVW | "movzbw" -> MOVZBW
  | "movzwl" -> MOVZWL | "movswl" -> MOVSWL | "repnz" -> REPNZ | "fildll" -> FILDLL | "filds" -> FILDS
  | "rep" -> REP | "cmovle" -> CMOVLE | "cmovg" -> CMOVG | "cmovl" -> CMOVL
  | "flds" -> FLDS | "fildl" -> FILDL | "fstl" -> FSTL | "fistpl" -> FISTPL | "fildq" -> FILDQ
  | "fsub" -> FSUB | "fdivs" -> FDIVS | "fistpll" -> FISTPLL | "fdivrp" -> FDIVRP
  | "cmovge" -> CMOVGE | "fcmovbe" -> FCMOVBE | "fsubp" -> FSUBP | "fild" -> FILD
  | "fistl" -> FISTL | "fsubrp" -> FSUBRP | "fsubrl" -> FSUBRL | "cwtl" -> CWTL
  | "fsubrs" -> FSUBRS | "fsubs" -> FSUBS | "fsubr" -> FSUBR | "fsubl" -> FSUBL
  | "fcmovnbe" -> FCMOVNBE | "fcmove" -> FCMOVE | "fcmovne" -> FCMOVNE
  | "fcmovb" -> FCMOVB | "fistp" -> FISTP | "fcmovnb" -> FCMOVNB
  | "cmovnp" -> CMOVNP | "stos" -> STOS | "stosb" -> STOSB | "fistps" -> FISTPS
  | "stosw" -> STOSW | "stosd" -> STOSD | "fistpq" -> FISTPQ
  | _ -> raise ParseError
and compareop_symb = function
  | "cmp" -> CMP | "test" -> TEST | "cmpl" -> CMPL
  | "cmpb" -> CMPB | "cmpw" -> CMPW | "testb" -> TESTB
  | "testl" -> TESTL | "cmpsb" -> CMPSB | "bt" -> BT | "btl" -> BTL
  | "testw" -> TESTW
  | _ -> raise ParseError
and setop_symb = function
| "seta" ->  SETA | "setae" -> SETAE | "setb" -> SETB | "setc" -> SETC
| "setnbe" ->  SETNBE | "setnc" -> SETNC | "setng" -> SETNG
| "setne" -> SETNE  | "sete" -> SETE | "setnp" -> SETNP
| "setge" -> SETGE | "setg" -> SETG | "setbe" -> SETBE
| "setle" -> SETLE | "setl" -> SETL | "setp" -> SETP | "setns" -> SETNS
| "sets" -> SETS
| _ -> raise ParseError
and otherop_symb = function
  | "nop" -> NOP | "hlt" -> HLT | _ -> raise ParseError

and stackop_symb = function
  | "push" -> PUSH | "pop" -> POP | "pushl" -> PUSHL | "popl" -> POPL
  |  _ -> raise ParseError

and jumpop_symb = function
  | "jmp" -> JMP | "jne" -> JNE | "je" -> JE
  | "jb" -> JB | "jnae" -> JNAE | "jc" -> JC
  | "jnb" -> JNB | "jae" -> JAE | "jnc" -> JNC
  | "jbe" -> JBE | "jna" -> JNA | "ja" -> JA
  | "jnbe" -> JNBE | "jl" -> JL | "jnge" -> JNGE
  | "jge" -> JGE | "jnl" -> JNL | "jle" -> JLE
  | "jng" -> JNG | "jg" -> JG | "jnle" -> JNLE
  | "js" -> JS | "jns" -> JNS | "jp" -> JP
  | "jnp" -> JNP
  | _ -> raise ParseError
and loopop_symb = function
  | "loop" -> LOOP | "loope" -> LOOPE | "loopne" -> LOOPNE
  | _ -> raise ParseError
and flagop_symb = function
  | "cld" -> CLD | "cltd" -> CLTD
  | _ -> raise ParseError
and control_symb = function
  | "call" -> (call_des := true; CALL) | "leave" -> LEAVE
  | "ret" -> RET
  | "retn" -> RETN
  | "fxam" -> FXAM | "fchs" -> FCHS
  | _ -> raise ParseError in

let controlop_symb = function s ->
  try Jump (jumpop_symb s) with _ ->
  try Loop (loopop_symb s) with _ ->
  try Flag (flagop_symb s) with _ ->
  try (control_symb s) with  _ ->
  raise ParseError

and systemp_symb = function
  | "int" -> INT | "in" -> IN
  | "out" -> OUT | _ -> raise ParseError in

let commonop_symb = function s ->
                     try Arithm (arithm_symb s)
                      with _ ->
                      try Logic (logicop_symb s)
                      with _ ->
                      try Rol (rolop_symb s)
                      with _ ->
                      try Assign (assignop_symb s)
                      with _ ->
                      try Compare (compareop_symb s)
                      with _ ->
                      try Set (setop_symb s)
                      with _ ->
                      try Other (otherop_symb s)
                      with _ -> raise ParseError in

let op_symb = function s ->
                try CommonOP (commonop_symb s)
                with _ ->
                try StackOP (stackop_symb s)
                with _ ->
                try ControlOP (controlop_symb s)
                with _ ->
                try SystemOP (systemp_symb s)
                with _ ->
                 raise ParseError in

let unptr_symb s =
  let l = String.length s in
    let s' = String.sub s 1 (l-2) in
      reg_symb s' in

let eiz_symb = function s ->
  let s' = String.trim s in
  let l = String.length s' in
    let s1 = String.sub s' 1 (l-2) in
  let split = Str.split (Str.regexp_string "+") in
    let items = split s1 in
      let offset = List.nth items 2
      and reg1 = List.nth items 0
      and reg2 = List.nth items 1 in
      if reg2 <> "eiz*1" then raise ParseError
      else
          (reg_symb reg1, reg_symb reg2, int_of_string offset) in

let assist_symb = function
| "scas" -> SCAS
| "cmpsb" -> CMPSB
| "stos" -> STOS
| "movsl" -> MOVSL
| "cmpsw" -> CMPSW
| _ -> raise ParseError
in

  object (self)

  val mutable func_list : func list = []
  val mutable sec_list : section list = []

method pp_print l =
  let rec help l =
    match l with
    | h::t -> (printf "item: %s") h; help t
    | [] -> print_string "end\n" in
    help l

method conptr_symb s =
  let split = Str.split (Str.regexp_string ":") in
    let items = split s in
      let addr = List.nth items 1 in
        let sec' = self#get_sec addr in
       (sec', int_of_string addr)

method ptraddr_symb s =
      try UnOP (unptr_symb s)
      with _ ->
      try BinOP_MINUS (binptr_m_symb s)
      with _ ->
      try BinOP_PLUS (binptr_p_symb s)
      with _ ->
      try FourOP (fourptr_symb s)
      with _ ->
      try FourOP_MINUS (fourptr_m_symb s)
      with _ ->
      try FourOP_PLUS (fourptr_p_symb s)
      with _ ->
      try JmpTable_PLUS (self#jmptable_p_symb s)
      with _ ->
      try JmpTable_MINUS (self#jmptable_m_symb s)
      with _ ->
      try SegRef (segref_symb s)
      with _ -> raise ParseError

method ptr_symb s =
  let has s1 s2 =
    let re = Str.regexp_string s2 in
    try ignore (Str.search_forward re s1 0); true
    with Not_found -> false in
  if ((has s "(")&&(has s ")")) then  (* then it should be ptr *)
   self#ptraddr_symb s
  else raise ParseError

(* this might be another approach, currently abandoned*)
method jumpdes_symb_bak s =
  let split = Str.split (Str.regexp " +") in
  let s1 = List.nth (split s) 1 in
  let s' = String.trim s1
  and split = Str.split (Str.regexp_string "+") in
    let items = split s' in
      let offset = List.nth items 1
      and func = List.nth items 0 in
        let func' = String.sub func 1 ((String.length func)-1)
        and offset' = String.sub offset 0 ((String.length offset)-1) in
        let f = self#get_func func' false in
          (f, int_of_string offset')

method jumpdes_symb s =
  if String.contains s '+' then
    let split = Str.split (Str.regexp " +") in
    let s1 = List.nth (split s) 0 in
     JumpDes (int_of_string ("0x"^s1))
  else if String.contains s '-' then
    let split = Str.split (Str.regexp " +") in
    let s1 = List.nth (split s) 0 in
     JumpDes (int_of_string ("0x"^s1))
  else  (* jmp deadbeef <func@plt> *)
    CallDes (self#calldes_symb s)


method calldes_symb (s: string) : func =
  let split = Str.split (Str.regexp " +") in
  let s1 = List.nth (split s) 1 in
  let s' = String.trim s1 in
    (* call   80484cb <__libc_start_main@plt+0x1ab> *)
    if String.contains s' '+' then
      let func = List.nth (split s) 0 in
        let func' = "S_0x"^(String.uppercase func) in
        let f = self#get_func func' false in
          f
    else if String.contains s' '-' then
      let func = List.nth (split s) 0 in
        let func' = "S_0x"^(String.uppercase func) in
        let f = self#get_func func' false in
          f
    else if String.contains s' '@' then
    let split = Str.split (Str.regexp_string "@") in
    let items = split s' in
      let item = List.nth items 0 in
        let func = String.sub item 1 ((String.length item)-1) in
        let f = self#get_func func true in
            f
    else
      let func = String.sub s' 1 ((String.length s')-2) in
        let f = self#get_func func true in
          f

method star_jmptable_symb s =
  if String.contains s '*' then
   let split = Str.split (Str.regexp_string ",") in
    let tokens = split s in
      let addr = List.nth tokens 0
      and r = List.nth tokens 1
      and off = List.nth tokens 2 in
        let addr' = String.sub addr 1 ((String.length addr)-2) in
        let off' = String.sub off 0 ((String.length off)-1) in
      (int_of_string addr', reg_symb r, int_of_string off')
  else raise ParseError

method jmptable_m_symb s =
  if String.exists s "(," then
   let split = Str.split (Str.regexp_string ",") in
    let tokens = split s in
      let addr = List.nth tokens 0 in
      if addr.[0] <>'-' then raise ParseError
    else
      let r = List.nth tokens 1
      and off = List.nth tokens 2 in
        let addr' = String.sub addr 1 ((String.length addr)-2) in
        let off' = String.sub off 0 ((String.length off)-1) in
      (int_of_string addr', reg_symb r, int_of_string off')
  else raise ParseError

method jmptable_p_symb s =
  if String.exists s "(," then
   let split = Str.split (Str.regexp_string ",") in
    let tokens = split s in
      let addr = List.nth tokens 0
      and r = List.nth tokens 1
      and off = List.nth tokens 2 in
        let addr' = String.sub addr 0 ((String.length addr)-1) in
        let off' = String.sub off 0 ((String.length off)-1) in
      (int_of_string addr', reg_symb r, int_of_string off')
  else raise ParseError

(* call *0x80808080(, %eax, 4) *)
method calljmp_symb s =
  if String.exists s "(," then
   let split = Str.split (Str.regexp_string ",") in
    let tokens = split s in
      let addr = List.nth tokens 0
      and r = List.nth tokens 1
      and off = List.nth tokens 2 in
        let addr' = String.sub addr 1 ((String.length addr)-2) in
        let off' = String.sub off 0 ((String.length off)-1) in
      (int_of_string addr', reg_symb r, int_of_string off')
  else raise ParseError

method leades_symb s =
  if String.exists s "(," then
   let split = Str.split (Str.regexp_string ",") in
    let tokens = split s in
      let addr = List.nth tokens 0
      and r = List.nth tokens 1
      and off = List.nth tokens 2 in
        let addr' = String.sub addr 0 ((String.length addr)-1) in
        let off' = String.sub off 0 ((String.length off)-1) in
      (int_of_string addr', reg_symb r, int_of_string off')
  else raise ParseError

method callstar_symb s =
  if s.[0] <> '*' then raise ParseError
else
  (
    let s' = String.sub s 1 (String.length s - 1) in
      (int_of_string s')
  )

method stardes_symb s =
  let s' = String.sub s 1 (String.length s - 1) in
    self#exp_symb s'

method symbol_symb s =
  let s' = String.trim s in
  if s'.[0] = '*' then
    StarDes (self#stardes_symb s')
  else if !call_des = true then
    (
      CallDes (self#calldes_symb s')
    )
  (* else if String.contains s '+' then *)
    else
       (self#jumpdes_symb s')

method exp_symb s =
   try Ptr (self#ptr_symb s)
   with _ ->
   try Reg (reg_symb s)
   with _ ->
   try Assist (assist_symb s)
   with _ ->
   try Const (const_symb s)
   with _ ->
   try Symbol (self#symbol_symb s)
   with _ ->
   try Label (s)   (* we jut consider these as labels *)
   with _ ->
   raise ParseError

method push_stack lex =
  match lex with
   | Lop s ->  Op (op_symb s)
   | Lexp s -> Exp (self#exp_symb s)
   | Lloc s -> Loc (loc_symb s)
   | _ -> raise ParseError

method reduce_stack stack =
  match stack with
   | (Loc l)::(Op p)::[] -> SingleInstr (p, l)
   | (Loc l)::(Exp exp1)::(Op p)::[] -> DoubleInstr(p, exp1, l)
   | (Loc l)::(Exp exp1)::(Exp exp2)::(Op p)::[] -> TripleInstr(p, exp1, exp2, l)
   | (Loc l)::(Exp exp1)::(Exp exp2)::(Exp exp3)::(Op p)::[] -> FourInstr(p, exp1, exp2, exp3, l)
   | _ -> raise ParseError

  method set_funclist l =
    func_list <- l

  method get_funclist =
    func_list

  method set_seclist l =
    sec_list <- l

  method get_func name lib =
    let rec help l name =
      match l with
      | h::t -> if h.func_name = name then h else help t name
      | [] ->
            let func' : func =
             {func_name=name; func_begin_addr=0; func_end_addr = 0; is_lib=lib;} in
               func_list <- func'::func_list;
               func' in
        help func_list name

  method get_sec addr =
    let rec help l addr =
      match l with
      | h::t -> (
                let b = h.sec_begin_addr in
                let e = b + h.sec_size in
                  if (addr>=b && addr < e)  then
                    h
                  else  help t addr)
      | [] -> print_string "error in get_sec"; raise ParseError in
      help sec_list (int_of_string addr)

  method init_process =
    call_des := false

  method init_count = 
    count := 0;

  method parse_instr instr loc =
    self#init_process;
    let lexem_list = Array.to_list (lexer instr loc) in
      let s : stack_type list = [] in
      let parse_one s l =
        match l with
        | Lend -> s
        | _ -> (self#push_stack l)::s
      in
      let stack = List.fold_left parse_one s lexem_list in
        self#reduce_stack stack

  initializer
    self#init_count;
end
