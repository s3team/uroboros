# here is the wired thing, in modified linker/assembler produced assembly code, 
# we can find wired "embedded C code", start with MACRO #APP and end with MACRO #NO_APP
# this situation can be found in perlbench final.perlbench.gcc.s


import sys, os

lines = []

fn = sys.argv[1]

with open(fn) as f:
    lines = f.readlines()

in_mac = False

def help(l):
	global in_mac
	if "#APP" in l:
		if in_mac == False:
			in_mac = True
			l = ""
		else:
			print "error: multiple APP macro detected"
	elif "#NO_APP" in l:
		if in_mac == True:
			in_mac = False
			l = ""
		else:
			print "error: multiple NO_APP macro detected"
	elif in_mac == True:
		l = ""
	return l
lines = map(lambda l : help(l), lines)

with open(fn+".new", 'w') as f:
	f.writelines(lines)