open Batteries

open Type
open Ail_parser
open Pp_print

(* diversify plugins *)

class ail (f : string) =
    object (self)
        val mutable funcs: string list = []
        val mutable func_content: string list = []
        val mutable func_tbl = Hashtbl.create 40


        method get_func_content (func : string) : string list = 
          let path = "./"^f^"_funcs/"^func in
          let filelines = File.lines_of path in
            func_content <- [];
            let () = Enum.iter (fun l -> func_content<- l::func_content) filelines in
              func_content

        method func_process (func : string) : instr list = 
          let path = "./"^f^"_funcs/"^func in
            Sys.command("python pre_prosess.py "^path);
          let instr_list = self#get_func_content func in
          let ail_parser = new ailParser in
            (* print_string (func^"\n"); *)
            ail_parser#process_instrs(instr_list);
            ail_parser#get_ir

        method get_func_list = 
          let filelines = File.lines_of "func_list_new" in
            let () = Enum.iter (fun l -> funcs<- l::funcs) filelines in
            ()

        method program_process =
          self#get_func_list;
          let help func = 
            let instrs = self#func_process func in 
              Hashtbl.replace func_tbl func instrs;
               in 
              List.iter help funcs;
              func_tbl

    end
