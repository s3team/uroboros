import sys, os


# fn1 is the compiler produced assembly code
fn1 = sys.argv[1]
# fn2 is the disassembler produced assembly code
fn2 = sys.argv[2]

blk = ['.cfi_', '.align', '.p2align', '.globl', '.comm', '.ident', '.long',
		'.local', '.data', '.zero','.bss']

# parse instruction like 8B150400 0000                                   movl    dummy+4, %edx
# into (8B, 6, is_jmpop)
# if len(l) < 36, just let it crash
def parse1(l):
	sub = l[0:35].strip()
	items = sub.split()
	op = items[0][0:2]  # get the opcode
	l1 = sum(map(lambda item : len(item), items))/2 # get the length of instructions
	sub1 = l[35:].strip()
	# print l
	if op == '89' and l1 == 9 and ".p2align" in l:
		l1 = 2
	if op == 'EB' and l1 == 15 and ".p2align" in l:
		l1 = 2
	if 'j' == sub1[0]:
		return (op, l1, True)
	else:
		return (op, l1, False)

def parse2(l):
	sub = l[0:35].strip()
	items = sub.split()
	op = items[0][0:2]  # get the opcode
	l1 = sum(map(lambda item : len(item), items))/2 # get the length of instructions
	sub1 = l[35:].strip()
	print l
	if ":" in sub1: # jump label
		sub1 = sub1.split(':')[1]
	if 'j' == sub1[0]:
		return (op, l1, True)
	else:
		return (op, l1, False)


is_text_sec = False

# here is one possiblity,
# 6690 .p2align 3
# as we can not eliminate 6690 in disassembler produced assembly code,
# we have to consider it as one instruction and do the comparation

def check_opcode(l):
	items = l.strip().split()
	if len(items) >=2:
    	    try:
        	int(items[0],16)
		t = items[0][0:2]
		if t == "90" or t == "8D":   # 90 would be translated into NOP in disassembler produced assembly code
        	    return False
		else:
        	    return True
    	    except ValueError:
        	return False
	else:
	    return False

def read_file1(l):
	global in_func
	global func_name
	global funcs_list
	global is_text_sec
	if ".section" in l and ".text" not in l:
		is_text_sec = False
		return
	if ".data" in l or ".rodata" in l or ".bss" in l:
		is_text_sec = False
		return
	elif ".text" in l:
		is_text_sec = True
		return
	elif is_text_sec == False:
		return
	elif any(item in l for item in blk) and check_opcode(l) == False:  #
		return
	else:
		items = l.split()
		if len(items) == 1:
			label = items[0].strip()
			if label[-1] == ':' and label[0:2] != '.L':
				fn = label[:-1]
				# function begin
				if fn in funcs:
					funcs_list1[fn] = []
					in_func = True
					func_name = fn
				else:
					print "error"+fn
		elif in_func == True:
			l = l.strip()
			if l == "" or "nop" in items or "lea 0x0(%esi),%esi" in l:
				return
			else:
				funcs_list1[func_name].append(parse1(l))


def read_file2(l):
	global in_func
	global func_name
	global funcs_list
	global is_text_sec
	if ".section" in l and ".text" not in l:
		is_text_sec = False
		return
	elif ".data" in l or ".rodata" in l or ".bss" in l:
		is_text_sec = False
		return
	elif ".text" in l:
		is_text_sec = True
		return
	elif is_text_sec == False:
		return
	else:
		items = l.split()
		if len(items) == 1:
			label = items[0].strip()
			if label[-1] == ':' and label[0:2] != '.L':
				fn = label[:-1]
				# function begin
				if fn in funcs:
					funcs_list2[fn] = []
					in_func = True
					func_name = fn
			else:
				print "error"+fn
		elif in_func == True:
			l = l.strip()
			if l == "" or "nop" in items or "nop;" in l or "lea 0x0(%esi),%esi" in l or "lea 0x0(%edi),%edi" in l:
				return
			if l[0] == '?':
				l = ' ' + l[1:]
			funcs_list2[func_name].append(parse2(l))


lines = []
with open(fn1) as f:
    lines = f.readlines()
map(lambda l : read_file1(l), lines)




in_func = False
func_name = ""

is_text_sec = False


lines = []
with open(fn2) as f:
    lines = f.readlines()
map(lambda l : read_file2(l), lines)


def do_comapre(o1, o2):
	(opcode1, len1, is_jmpop1) = o1
	(opcode2, len2, is_jmpop2) = o2
	if opcode1 != opcode2:
		if is_jmpop1 == False or is_jmpop2 == False:
			return False
	else:
		if len1 == len2:
			return True
		else:
			return False

fail_list = []

def compare(fn, oplist1):
	global funcs_list2
	oplist2 = funcs_list2[fn]
	if len(oplist1) != len(oplist2):
		if len(oplist2) == len(oplist1) + 1 and oplist2[-1] == ('EB', 2, True):
# http://stackoverflow.com/questions/25967069/wired-instruction-identified-on-disassembler-produced-assembly-code
			oplist2 = oplist2[:-1]
			if any(do_comapre(oplist1[i], oplist2[i])== False for i in range(0, len(oplist1))):  #
				print "fail "+fn
				fail_list.append(fn)
			else: # pass
				return
		else:
			print "length fail " + fn
			fail_list.append(fn)
	else:
		if any(do_comapre(oplist1[i], oplist2[i])== False for i in range(0, len(oplist1))):  #
			print "fail "+fn
			fail_list.append(fn)
		else: # pass
			return
for k,v in funcs_list1.items():
	compare(k,v)

def print_help(fn, tbl):
    fc = tbl[fn]
    print fn
    for i in fc:
        print "    " + str(i)
map(lambda fn : print_help(fn, funcs_list1), fail_list)
map(lambda fn : print_help(fn, funcs_list2), fail_list)
