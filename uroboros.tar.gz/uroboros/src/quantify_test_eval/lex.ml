(*basically, lexer consume a string: string_lexer and create a lex:lexeme
 assemble code's parser should be quite easy*)

open Batteries
open Printf

type lexeme = | Lop of string
              | Lexp of string
              | Lloc of string
              | Lend
exception LexerError

let pp_print l =
  let rec help l =
    match l with
    | h::t -> (printf "item: %s") h; help t
    | [] -> print_string "end\n" in
    help l

(* switch from identify coma to regex pattern match
 * 1:  identify 0x4(%eax, %ebx, 4)
 *      regex pattern:  0x\d+\(\%\w+,\%\w+,\d\)
 * 2:  jmp  *0x80509e4(,%eax,4)
 * *)

let check_star_jmptable exp =
  let re_jmp = Str.regexp "/*0x[0-9a-f]+(,%[a-z]+,[0-9a-f]+)" in
  let jmp_pat s =
    try ignore (Str.search_forward re_jmp s 0); true
    with Not_found -> false in
  jmp_pat exp

let star_jmptable_exp exp op location =
  let lexm = Array.create 3 Lend in
    lexm.(0) <- Lop op;
    lexm.(1) <- Lexp exp;
    lexm.(2) <- Lloc location;
    lexm

(* this is one of the tricky thing, see two kinds of instructions below
 *  mov  0x805e17c(,%ebx,4),%eax
 *  mov  %eax,0x805e17c(,%ebx,4)
 *  here an ad-hoc way to judge whether it is type 1 or type 2 based on first %
 *  *)

let check_jmptable exp =
  (* let re_jmp = Str.regexp "S?_?0x[0-9a-f]+(,%[a-z]+,0?x?[0-9a-f]+)" in *)
  let re_jmp = Str.regexp "S?_?[0-9\+_\.a-zA-Z]+-?[0-9\+_\.a-zA-Z]+(,%[a-z]+,0?x?[0-9a-f]+)" in
  let jmp_pat s =
    try ignore (Str.search_forward re_jmp s 0); true
    with Not_found -> false in
  jmp_pat exp

let check_jmptable_type exp =
  let exp' = String.trim exp in
  if exp'.[0] = '%' then 1
  else if exp'.[0] = '$' then 1
  else 2

let jmptable_exp exp op location t =
  let items = Str.split (Str.regexp_string ",") exp in
  let re_jmp = Str.regexp "S?_?[0-9\+_\.a-zA-Z]+-?[0-9\+_\.a-zA-Z]+(,%[a-z]+,0?x?[0-9a-f]+)" in
  let e =
    (
      ignore(Str.search_forward re_jmp exp 0);
      Str.matched_string exp
    ) in
  let exp' = String.trim exp in 
  (* fstl   0x8066b60(,%eax,8)* *)
  if e == exp' then 
    let lexm = Array.create 4 Lend in
      lexm.(0) <- Lop op;
      lexm.(1) <- Lexp e;
      lexm.(2) <- Lloc location;
      lexm 
  else
    begin
    let ls = String.length exp' in
      if exp'.[ls-1] == ')' then (* jump table is the second exp *) 
        let e1 = List.nth items 0 
        and e2 = e in
          let lexm = Array.create 5 Lend in
            lexm.(0) <- Lop op;
            lexm.(1) <- Lexp e1;
            lexm.(2) <- Lexp e2;
            lexm.(3) <- Lloc location;
            lexm
      else 
        let e1 = e
        and e2 = List.nth items ((List.length items) -1) in
          let lexm = Array.create 5 Lend in
            lexm.(0) <- Lop op;
            lexm.(1) <- Lexp e1;
            lexm.(2) <- Lexp e2;
            lexm.(3) <- Lloc location;
            lexm
    end

let check_imul_op op =
 let assist_list = ["imul"] in
    try ignore (List.find (fun i-> i = op) assist_list); true
    with Not_found -> false

let imul_exp exp op location =
  let cat_tail s =
    match s with
    | [] -> [] (* this will never happen*)
    | h::t -> t in
  let rec trim_end l =
    match l with
      | e::[] -> []
      | [] -> []
      | h::t -> h::(trim_end t) in
  let exp' = String.trim exp in
    let items = Str.split (Str.regexp_string ",") exp in
    if List.length items = 2 then  (* two exp : FIXME *)
      let lexm = Array.create 5 Lend in
        lexm.(0) <- Lop op;
        lexm.(1) <- Lexp (List.nth items 0);
        lexm.(2) <- Lexp (List.nth items 1);
        lexm.(3) <- Lloc location;
        lexm
    else if List.length items = 3 then (* three exp *)
      let ll = List.length items
      and me = trim_end (cat_tail items) in
      let me' = String.concat "," me in
      let lexm = Array.create 6 Lend in
        lexm.(0) <- Lop op;
        lexm.(1) <- Lexp (List.nth items 0);
        lexm.(2) <- Lexp me';
        lexm.(3) <- Lexp (List.nth items (ll-1));
        lexm.(4) <- Lloc location;
        lexm
    else if List.length items = 4 then (* imul   0x8110680(,%eax,4),%ebx *)
	begin
	if String.get exp 0 == '0' then 
      	  let ll = List.length items
      	  and exp1l = trim_end items in
      	  let exp1 = String.concat "," exp1l in
      	  let lexm = Array.create 5 Lend in
        	lexm.(0) <- Lop op;
        	lexm.(1) <- Lexp exp1;
        	lexm.(2) <- Lexp (List.nth items (ll-1));
        	lexm.(3) <- Lloc location;
        	lexm
	else
      	  let ll = List.length items
      	  and exp2l = cat_tail items in
      	  let exp2 = String.concat "," exp2l in
      	  let lexm = Array.create 5 Lend in
        	lexm.(0) <- Lop op;
        	lexm.(1) <- Lexp (List.nth items 0);
        	lexm.(2) <- Lexp exp2;
        	lexm.(3) <- Lloc location;
        	lexm
	end
    else if List.length items = 5 then 
	(* three exp  imul $0x78,0x80b0380(,%ebp,4),%edx *)
      let ll = List.length items
      and me = trim_end (cat_tail items) in
      let me' = String.concat "," me in
      let lexm = Array.create 6 Lend in
        lexm.(0) <- Lop op;
        lexm.(1) <- Lexp (List.nth items 0);
        lexm.(2) <- Lexp me';
        lexm.(3) <- Lexp (List.nth items (ll-1));
        lexm.(4) <- Lloc location;
        lexm
    else failwith (exp^"unsupported situation in imul lex")
		
	

let check_single_op op =
 let assist_list = ["divl"; "divb"; "divw"; "call"; "div"] in
    try ignore (List.find (fun i-> i = op) assist_list); true
    with Not_found -> if op.[0] = 'j' then true (* FIXME? *)
    else false

let single_exp exp op location =
  let exp' = String.trim exp in
    let lexm = Array.create 4 Lend in
      lexm.(0) <- Lop op;
      lexm.(1) <- Lexp exp';
      lexm.(2) <- Lloc location;
      lexm

let check_assist exp =
  let assist_list = ["cmpsb"; "scas"; "stos"; "movsl"; "movsb"; "cmpsw"] in
    try ignore (List.find (fun i-> i = exp) assist_list); true
    with Not_found -> false

let assist_exp op ass exp location =
   let items = Str.split (Str.regexp_string ",") exp in
    let lexm = Array.create 6 Lend in
    lexm.(0) <- Lop op;
    lexm.(1) <- Lexp ass;
    lexm.(2) <- Lexp (List.nth items 0);
    lexm.(3) <- Lexp (List.nth items 1);
    lexm.(4) <- Lloc location;
    lexm

let complex_exp exp op location =
  (* let re = Str.regexp "-?0*x*[0-9a-f]*(%[a-z]+,%[a-z]+,0*x*[0-9a-f]+)" in *)
  let re = Str.regexp "-?[0-9\+_\.a-zA-Z]+-?[0-9\+_\.a-zA-Z]+(%[a-z]+,%[a-z]+,0?x?[0-9a-f]+)" in
  let pat s =
    try ignore (Str.search_forward re s 0); Some (Str.matched_string s)
    with Not_found -> None
  and trim_str1 s b =
    let l = (String.length exp) - b in
      String.sub exp b l
  and trim_str2 s =
    let l = (String.length exp) - (String.length s) - 1 in
      String.sub exp 0 l
  and cat_nolast l sep =
    let p = object
      val mutable acc : string = ""
      method set l sep =
        let rec help li =
          match li with
            | [h] -> acc
            | h::t -> (acc <- acc^sep^h; help t)
            | [] -> failwith "empty list" in
          help l
      method get = acc
    end in
      p#set l sep;
      p#get in
  let split_str s =
    let exp' = String.trim exp in
      if s = exp' then
        let lexm = Array.create 4 Lend in
          lexm.(0) <- Lop op;
          lexm.(1) <- Lexp s;
          lexm.(2) <- Lloc location;
          lexm
      else
    let i = String.find exp s in
      if i = 0 then
              let su = trim_str1 s ((String.length s) + 1) in
                let lexm = Array.create 5 Lend in
                  lexm.(0) <- Lop op;
                  lexm.(1) <- Lexp s;
                  lexm.(2) <- Lexp su;
                  lexm.(3) <- Lloc location;
                  lexm
      else
              let su = trim_str2 s in
                let lexm = Array.create 5 Lend in
                  lexm.(0) <- Lop op;
                  lexm.(1) <- Lexp su;
                  lexm.(2) <- Lexp s;
                  lexm.(3) <- Lloc location;
                  lexm in
  match (pat exp) with
  | Some e -> split_str e
  | None -> (
              let subtokens = Str.split (Str.regexp_string ",") exp in
              let sub_len = List.length subtokens in
              if sub_len = 4 then (* lea    0x0(,%ebp,8),%eax *)
                let head = cat_nolast subtokens "," in
               let lexm = Array.create 5 Lend in
                lexm.(0) <- Lop op;
                lexm.(1) <- Lexp head;
                lexm.(2) <- Lexp (List.nth subtokens 3);
                lexm.(3) <- Lloc location;
                lexm
              else if sub_len = 3 then (* imul   $0xe10,%ebp,%eax *)
              let lexm = Array.create 6 Lend in
                lexm.(0) <- Lop op;
                lexm.(1) <- Lexp (List.nth subtokens 0);
                lexm.(2) <- Lexp (List.nth subtokens 1);
                lexm.(3) <- Lexp (List.nth subtokens 2);
                lexm.(4) <- Lloc location;
                lexm
              else if sub_len = 2 then (* common case*)
              let lexm = Array.create 5 Lend in
                lexm.(0) <- Lop op;
                lexm.(1) <- Lexp (List.nth subtokens 0);
                lexm.(2) <- Lexp (List.nth subtokens 1);
                lexm.(3) <- Lloc location;
                lexm
              else
                let _ = print_int sub_len in
                failwith "unknown length of instruction"
            )

let check_jmptable_1 instr = 
    let con1 = String.exists instr "(," 
    and con2 = String.exists instr ")," 
    and con3 = String.exists instr ",0x" in 
	if con1 == true && con2 == false && con3 == false then
		true
	else false

let lexer' instr' location' =
  let instr = String.trim instr'
  and location = String.trim location' in
  let cat_tail s =
    match s with
    | [] -> "" (* this will never happen*)
    | h::t -> String.trim (String.concat " " t)
  and split = Str.split (Str.regexp " +") in
  let tokens = split instr in
  (* let tokens = List.map String.trim tokens in *)
  let tokens_len = List.length tokens
  and op_str = List.nth tokens 0 in
  if tokens_len = 1 then
  let lexm = Array.create 3 Lend in
  lexm.(0) <- Lop op_str;
  lexm.(1) <- Lloc location;
  lexm

  else if (String.exists instr ",") = false then
      let sub = cat_tail tokens in
        let lexm = Array.create 4 Lend in
        lexm.(0) <- Lop op_str;
        lexm.(1) <- Lexp sub;
        lexm.(2) <- Lloc location;
        lexm
  else if check_imul_op op_str = true (* should have two or three exp *)
    then imul_exp (cat_tail tokens) op_str location
  else if check_single_op op_str = true (* should have jmptable or related instr now *)
    then single_exp (cat_tail tokens) op_str location
  else if check_jmptable (cat_tail tokens) = true
  then
    (
      let c = check_jmptable_type (cat_tail tokens) in
        jmptable_exp (cat_tail tokens) op_str location c
    )
  else if check_assist (List.nth tokens 1)
  then assist_exp op_str (List.nth tokens 1) (List.nth tokens 2) location
  else complex_exp (cat_tail tokens) op_str location


let p_print lexme =
    match lexme with
    | Lend -> print_string " (End)\n"
    | Lop s -> print_string (" (Op "^s^")")
    | Lexp s -> print_string (" (Exp "^s^")")
    | Lloc  s -> print_string (" (Loc "^s^")")

let strip_array lexme = 
    match lexme with
    | Lend -> Lend
    | Lop s -> Lop (String.trim s)
    | Lexp s -> 
      begin
        let s' = String.trim s in 
          let ls = String.length s' in 
            if s'.[ls-1] == ',' && s'.[0] == ',' then 
              Lexp(String.sub s' 1 (ls-2))
            else if s'.[ls-1] == ',' then 
             Lexp(String.sub s' 0 (ls-1))
            else if s'.[0] == ',' then 
             Lexp(String.sub s' 1 (ls-1))
            else
             Lexp(s')
      end
    | Lloc  s -> Lloc (String.trim s)

let check_integer s = 
	try 
		ignore(int_of_string s);
		"nop"
	with 
  | _ -> s 

let lexer instr location =
  print_string (instr^"\n");  
	let instr' = 
	if String.length instr == 0 then 
		"nop" 
	else check_integer instr in
  let tokens = lexer' instr' location in
    Array.iter p_print tokens;
    Array.map strip_array tokens; 
    (* tokens *)
