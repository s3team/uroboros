open Batteries

open Type
open Pp_print


type mining_type = Label_type of string | Call_type of string | Other_type of string
type label_type = 
              (*  S_xxxx(,%eax,4) *)
                | Array1_type  
              (*  S_xxxx(%ebp,%edx,4) *)
                | Array2_type 
              (*  string label *)
                | Normal_type

class ail_ir_mining =
    object (self)

      val mutable symbols= Hashtbl.create 40

      method process_func_count f_tbl =
	      print_string "###################### func count mining ###########\n";
            let func_iter (fn: string) (il : instr list) : unit = 
                print_string fn;
                let l = List.length il in
                print_string (" : "^(string_of_int l)^"\n");
                () in 
            Hashtbl.iter func_iter f_tbl;
	    print_string "###################### func count mining ###########\n";

        method is_symbol_str (e : exp) : string option = 
            let rec help = function
                | Symbol s -> 
                    begin
                        match s with
                        | StarDes e' -> help e'
                        | CallDes _ -> Some("Function Call")
                        | _ -> None
                    end
                | Ptr p -> 
                    begin
                        match p with
                          | BinOP_PLUS_S _ -> Some("BinOP Plus")
                          | BinOP_MINUS_S _ -> Some("BinOP Minus")
                          | FourOP_PLUS_S _ -> Some("FourOP PLUS")
                          | FourOP_MINUS_S _ -> Some("FourOP Minus")
                          | JmpTable_PLUS_S _ -> Some("JmpTable Plus")
                          | JmpTable_MINUS_S _ -> Some("JmpTable Minus")
                          | _ -> None
                    end
                | Label l -> (* 
                    if String.exists l "$0xffff" || String.exists l "$0xffdf" then
                        None
                    else
                         On 32bit OCaml system,  value like 0xffffffff go beyond 
                        the maximum integer, so we make it as a label, 
                        however, we don't count it in when mining *)
                        Some(l^" Label")
                | _ -> None  in 
                help e


        method is_symbol_ty (e : exp) : mining_type option = 
            let rec help = function
                | Symbol s -> 
                    begin
                        match s with
                        | StarDes e' -> help e'
                        | CallDes _ -> Some(Call_type("Function Call"))
                        | _ -> None
                    end
                | Ptr p -> 
                    begin
                        match p with
                          | BinOP_PLUS_S _ -> Some(Other_type("BinOP Plus"))
                          | BinOP_MINUS_S _ -> Some(Other_type("BinOP Minus"))
                          | FourOP_PLUS_S _ -> Some(Other_type("FourOP PLUS"))
                          | FourOP_MINUS_S _ -> Some(Other_type("FourOP Minus"))
                          | JmpTable_PLUS_S _ -> Some(Other_type("JmpTable Plus"))
                          | JmpTable_MINUS_S _ -> Some(Other_type("JmpTable Minus"))
                          | _ -> None
                    end
                | Label l -> (* 
                    if String.exists l "$0xffff" || String.exists l "$0xffdf" then
                        None
                    else
                         On 32bit OCaml system,  value like 0xffffffff go beyond 
                        the maximum integer, so we make it as a label, 
                        however, we don't count it in when mining *)
                        (
                          print_string ("   "^l^" symbol\n");
                          Some(Label_type(l^" Label"))
                        )
                | _ -> None  in 
                help e

        method symbol_collect f_tbl =
            print_string "###################### symbol collecting ###########\n";
            let func_iter (fn : string) (il : instr list) : unit = 
                print_string (fn^"\n");
                let ir_fold (acc : mining_type list) (i : instr) : mining_type list = 
                    match i with
                        | SingleInstr (p, l) -> acc
                        | DoubleInstr (p, e, l) ->
                            begin
                                match self#is_symbol_ty e with
                                 | Some s  -> s::acc
                                 | None -> acc
                            end
                        | TripleInstr (p, e1, e2, l) -> 
                            begin
                                let acc' = 
                                    match self#is_symbol_ty e1 with
                                       | Some s  -> s::acc
                                       | None -> acc in
                                match self#is_symbol_ty e2 with
                                   | Some s  -> s::acc'
                                   | None -> acc'
                            end
                        | FourInstr (p, _, e, _, l) -> 
                           begin
                                match self#is_symbol_ty e with
                                 | Some s  -> s::acc
                                 | None -> acc
                            end in 
                  Hashtbl.replace symbols fn (List.fold_left ir_fold [] il)
            in
              Hashtbl.clear symbols;
              Hashtbl.iter func_iter f_tbl;
              print_string "###################### symbol collecting ###########\n"; 
              Hashtbl.copy symbols        


        method check_label (s : string) : label_type =
          if String.exists s ","  == false then 
            (
              (* print_string ("normal type : "^s^" "); *)
              Normal_type
            )
          else
            begin
              let items = Str.split (Str.regexp_string ",") s in
                if List.length items == 3 && String.exists s "(," then
                  Array1_type
                else if List.length items == 3 then
                  Array2_type
                else 
                  failwith "unsupported type"
            end


        method symbol_compare symbols1 symbols2 =
          let rec help(sl1 : mining_type list) (sl2 : mining_type list) =
            match (sl1, sl2) with
              | ([], []) -> ()
              | ([], _) -> failwith "   symbols in set1 ls less fail\n"
              | (_, []) -> failwith "   symbols in set2 ls less fail\n"
              | (h1::t1, h2::t2) -> 
                begin
                  match (h1,h2) with
                    | (Call_type _, Call_type _) ->(print_string "    pass call\n"; help t1 t2) 
                    | (Other_type _, Other_type _) -> (print_string "   pass other\n"; help t1 t2) 
                    | (Label_type s1, Label_type s2) -> 
                      begin
                       match (self#check_label s1, self#check_label s2) with
                          | (Array1_type, Array1_type) -> (print_string "   pass label1\n "; help t1 t2)
                          | (Array2_type, Array2_type) -> (print_string "   pass label2\n"; help t1 t2)
                          | (Normal_type, Normal_type) -> (print_string "   pass label3\n"; help t1 t2)
                          | _ -> failwith "mismatched type in symbol compare"
                      end
                    | _ -> failwith "mismatched type in symbol compare"
                end
              | _ -> failwith "error length in symbol compare " in (* this is impossible*)
            let func_iter fn1 sl1 = 
              try
                let sl2 = Hashtbl.find symbols2 fn1 in 
                  let sl1_len = List.length sl1
                  and sl2_len = List.length sl2 in
                    print_string (fn1^" "^(string_of_int sl1_len)^" "^(string_of_int sl2_len)^"\n"); 
(*                     if sl1_len <> sl2_len then 
                      failwith ""
                    else *)
                      ignore(help sl1 sl2);
                  print_string ("symbol compare on function "^fn1^" pass!\n")
              with
                | _ -> print_string ("symbol compare on function "^fn1^" fail!\n") in 
              Hashtbl.iter func_iter symbols1


        method symbol_count f_tbl = 
            print_string "###################### symbol count mining ###########\n";
            let func_iter (fn : string) (il : instr list) : unit = 
                (* print_string (fn^" :\n"); *)
                let ir_fold (c : int) (i : instr) : int = 
                    match i with
                        | SingleInstr (p, l) -> c
                        | DoubleInstr (p, e, l) ->
                            begin
                                match self#is_symbol_str e with
                                 | Some s  ->
                                    (
                                        let n = l.loc_addr in
                                          print_string ((string_of_int n)^" : "^s^"\n");
                                        c + 1
                                    )
                                 | None -> c
                            end
                        | TripleInstr (p, e1, e2, l) -> 
                            begin
                                let c' = 
                                    match self#is_symbol_str e1 with
                                     | Some s  -> (  let n = l.loc_addr in
                                          print_string ((string_of_int n)^" : "^s^"\n"); 
                                      c + 1)
                                     | None -> c  in
                                match self#is_symbol_str e2 with
                                | Some s -> (   let n = l.loc_addr in
                                          print_string ((string_of_int n)^" : "^s^"\n"); 
                                            c'+1 )
                                | None -> c'
                            end
                        | FourInstr (p, _, e, _, l) -> 
                           begin
                                match self#is_symbol_str e with
                                 | Some s  -> (   let n = l.loc_addr in
                                          print_string ((string_of_int n)^" : "^s^"\n"); 
                                      c + 1 )
                                 | None -> c
                            end in 
                let sc = List.fold_left ir_fold 0 il in 
                    print_string ("    symbols : "^(string_of_int sc)^"\n"); in 
                Hashtbl.iter func_iter f_tbl;
            print_string "###################### symbol count mining ###########\n";
    end
