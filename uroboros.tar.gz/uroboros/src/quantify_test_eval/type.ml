type file =
            {
               name: string;
               striped: bool; (*whether this file has been stripped*)
               format: string; (*ELF, PE, MachOS or even COFF*)
               is32bit: bool; (*whether this file is compiled 32 bit or not*)
            }
and section =
    {
        sec_name: string;
        sec_begin_addr : int;
        sec_size: int;
    }
and func =
    {
        func_name: string;
        func_begin_addr : int;
        func_end_addr : int;
        is_lib: bool;
    }
(* basic block defination
 * In order to do bb level diversify,
 * one critical thing is that
 *    whether the preceding block is **fall-through** to current block
 *    like this:
 *
 *  BB1
 *  {
 *     instr1;
 *     instr2;
 *     instr3;
 *  }
 *  BB2
 *  {
 *     L:
 *      instr1'
 *      instr2'
 *      instr3'
 *      instr4'
 *  }
 *
 *    or it can not be reached directly by preceding block like this:
 *
 *  BB1
 *  {
 *     instr1;
 *     instr2;
 *     call/jmp L';
 *  }
 *  BB2
 *  {
 *      instr1'
 *      instr2'
 *      instr3'
 *      instr4'
 *  }
 *
 * The key observation is whether the last instruction of preceding block is
 *  ControlOP or not
 *
 *  Even though it might have no difference comparing these two situations
 *  in the context of diversity, but it should be necesnny to record this info
 *
 *  we will record the preceding block with current block
 *  as well as current block with succeeding block
 *
 **)
and bblock =
    {
        bf_name: string; (* which function belongs to*)
        bblock_name : string;
        bblock_begin_loc : loc;
        bblock_end_loc : loc;
        (* preceding_direct_reach : bool; *)
        (* succeeding_direct_reach : bool; *)
    }
and loc =
    {
        loc_label : string;
        loc_addr : int;
    }
type op =
  | CommonOP of commonop
  | StackOP of stackop
  | ControlOP of controlop
  | SystemOP of systemop
and commonop =
  | Arithm of arithmop
  | Logic of logicop
  | Rol of rolop
  | Assign of assignop
  | Compare of compareop
  | Set of setop
  | Other of otherop
and controlop =
  | Jump of jumpop
  | Loop of loopop
  | Flag of flagop
  | CALL | LEAVE |RET | RETN | FXAM | FCHS
and stackop = PUSH | POP | PUSHL | POPL
and systemop = INT | IN | OUT
and arithmop = ADC | ADD | XADD | SUB | ADDL | SUBL
               | MUL | IMUL | DIV | IDIV | DIVL | ADCL | IDIVL
               | INC | INCL | DEC | NEG | SBB | FADD | NEGL | FMUL
               | FXCH | FUCOMIP | FUCOMI | BSR | MULL | FMULL
               | ADDW | FMULP | FMULS | FADDS | FADDP | FADDL
               | SUBW | IMULL | BSWAP | DECL | FDIV | FDIVL
               | ADDB | SUBB | SBBL | FDIVR | FABS | FSQRT | FDIVRS
               | FRNDINT | FDIVRL | FPREM
and logicop = AND | ANDB | OR | XOR | XORW | NOT | ANDL | NOTL | ORW | XORB | XORL
               | SAHF | ANDW | NOTB | NOTW
and rolop = ROL | SHL | SHR | SHLD |SHRD | SHRL | ROR | RORL
            | SAL | SALL | SAR | SHLL | ROLL | SHRB | SHLB | SARL | ROLW | SHLW
            | SARW | SHRW | SARB
and assignop = MOV | XCHG | LEA | LEAL | MOVSX | MOVL | FLDL | MOVZBL | MOVZBW
               | MOVW | MOVZX | FLD | FSTP | CMOVAE | CMOVE | CMOVNE
               | CMOVBE | CMOVB | CMOVS | CMOVA | CMOVNS | MOVB
               | MOVZWL | MOVSWL | MOVSBL | MOVSBW | FLDT | FSTPT | ORL | ORB
               | FNSTCW | FLDCW | FLDZ | REPZ | REPE | FSTPL | REPNZ
               | REP | FNSTSW | CMOVLE | CMOVG | CMOVL | FILDLL | FILDS
               | FLDS | FILDL | FLD1 | FDIVP | FSTL | FISTPL | FILD | FILDQ | FISTPQ
               | FSUB | FDIVS | FISTPLL | FDIVRP | CMOVGE | FCMOVBE
               | FSUBP | FISTL | FSUBRP | FSUBRL | CWTL | FSUBRS | FSTPS
               | FSUBS | FSUBR | FSTS | FSUBL | FCMOVNBE | FCMOVE | FCMOVNE
               | FCMOVB | FISTP | FCMOVNB | CMOVNP | STOS | STOSB | STOSW | STOSD | FISTPS
and compareop = CMP | TEST | CMPL | CMPB | CMPW | TESTB | TESTL | CMPSB | BT | BTL | TESTW
and setop = SETA | SETAE | SETB | SETBE | SETC
            | SETNBE | SETNC | SETNG | SETNE
            | SETE | SETNP | SETGE | SETG | SETLE
            | SETL | SETP | SETNS | SETS
and otherop = NOP | HLT
and jumpop = JMP | JNE | JE | JB | JNAE | JNP
              | JC | JNB | JAE | JNC | JBE | JNA
              | JA | JNBE | JL | JNGE | JGE | JNL | JLE
              | JNG | JG | JNLE | JS | JNS | JP
and loopop = LOOP | LOOPE |LOOPNE
and flagop = CLD | CLTD
and assistop = SCAS | CMPSB | STOS | MOVSL | MOVSB | CMPSW
and reg =
  | CommonReg of commonreg
  | StackReg of stackreg
  | PCReg of pcreg (*Program counter, probabaly we don't need this*)
  | OtherReg of otherreg
and commonreg =
  | EAX | EBX | ECX | EDX | EDI | ESI
  | AX | BX | CX | DX | AL | BL | CL | DL
  | AH | BH | CH | DH
and stackreg =
  | ESP | EBP
and pcreg = EIP
and otherreg = EIZ
and ptrtyp = QWORD | DWORD | WORD | TBYTE | BYTE
and mathop = MATHADD | MATHSUB
and seg = FS | GS | CS | SS | DS | ES
     deriving (Show)
type symbol =
  (* | JumpDes of (func * int) jle    8048427 <main+0x43> *)
  | JumpDes of int (*jle    8048427 <main+0x43>,   we only take 8048427 *)
  | CallDes of func (*call   8048300 <printf@plt>*)
  | StarDes of exp (*call/jmp   *exp  typically exp could be const; jmptable; ptr*)
  (*jmp *0x80509e4(,%eax,4)*)
  (* | StarDes_S of (string * reg * int) (*jmp *S_0x80509E4(,%eax,4)*) *)
  (* | LeaDes of (int * reg * int) *)
   (*lea    0x0(,%ebp,8),%eax  so basically this is a quite rare situation. *)
and const =
  | Point of int (* 0x8048440*) | Normal of int (* $0x8048440*)
and exp =
| Const of const
| Symbol of symbol
| Reg of reg
| Assist of assistop (*this is rare:   repz ret*)
| Ptr of ptraddr
| Label of string
and ptraddr =
  | UnOP of reg
  (* mov (%eax) ,%eax *)
  | BinOP_PLUS of (reg * int)
  | BinOP_PLUS_S of (reg * string)
  (* mov 0x3c(%esp),%eax *)
  | BinOP_MINUS of (reg * int)
  (* mov -0x3c(%esp),%eax *)
  | BinOP_MINUS_S of (reg * string)
  (* mov -0x3c(%esp),%eax *)
  | FourOP of (reg * reg * int)
  (* mov (%esp,%eax,4),%edx *)
  | FourOP_PLUS of (reg * reg * int * int)
  (* mov 0x18(%esp,%eax,4),%edx *)
  | FourOP_MINUS of (reg * reg * int * int)
  (* mov -0x18(%esp,%eax,4),%edx *)
  | FourOP_PLUS_S of (reg * reg * int * string)
  (* mov S_0x8048050(%esp,%eax,4),%edx *)
  | FourOP_MINUS_S of (reg * reg * int * string)
  (* mov -S_0x8048050(%esp,%eax,4),%edx *)
  | JmpTable_PLUS of (int * reg * int) (* mov 0x805e17c(,%ebx,4),%eax *)
  | JmpTable_MINUS of (int * reg * int) (* lea -4(,%ebx,4),%eax *)
  | JmpTable_PLUS_S of (string * reg * int) (* mov S_0x805e17c(,%ebx,4),%eax *)
  | JmpTable_MINUS_S of (string * reg * int) (* lea -S_0x805e17c(,%ebx,4),%eax *)
  | SegRef of (seg * reg)
  (* rep stos %al,%es:(%edi)*)
and instr =
  | SingleInstr of op * loc
  | DoubleInstr of op * exp * loc
  | TripleInstr of op * exp * exp * loc
  | FourInstr of op * exp * exp * exp * loc
  (* as far as I know, imul $0xe10,%ebp,%eax *)
