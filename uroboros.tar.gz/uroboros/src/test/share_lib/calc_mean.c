//#include <stdio.h>

static c;
int d = 2;

double mean(double a, double b) {
	printf("hello\n");
	c = 2;
	printf("%d\n", c);

	if (a > 1) 
	{
		printf("%d\n", c);
		int e = 123;
		int f = 123;
		int g = 123;
		printf("%d%d%d\n", e,f,g);
		mean(1,2);
	}
	else
		printf("this is very wired\n");

	return (a+b) / 2;

}
