double mean(double, double);
int d;
