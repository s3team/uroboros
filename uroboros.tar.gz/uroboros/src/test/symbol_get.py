# get all the resolved symbol information from relocation table


# input the name of a binary compiled with -q
# example:
#    gcc -Wl,-q simple.c


import os, sys

fn = sys.argv[1]



os.system('readelf -SW ' + fn + " > " + fn + '.secs')
os.system('objdump -Dr -j .text ' + fn + ' > '+fn + '.dis')
os.system('readelf -r ' + fn + ' > '+fn + '.sym')

fn1 = fn + '.dis'
fn2 = fn + '.sym'
fns = fn + '.secs'

lines1 = []
with open(fn1) as f:
    lines1 = f.readlines()

lines2 = []
with open(fn2) as f:
    lines2 = f.readlines()

lines_secs = []
with open(fns) as f:
    lines_secs = f.readlines()

tb = 0
te = 0
rdb = 0
rde = 0
db = 0
de = 0
bb = 0
be = 0

for l in lines_secs:
    if ".text" in l and "PROGBITS" in l:
        tb = int(l.split()[3], 16)
        te = tb + int(l.split()[5], 16)
    if ".rodata" in l and "PROGBITS" in l:
        rdb = int(l.split()[3], 16)
        rde = rdb + int(l.split()[5], 16)
    if ".data" in l and "PROGBITS" in l:
        db = int(l.split()[3], 16)
        de = db + int(l.split()[5], 16)
    if ".bss" in l and "NOBITS" in l:
        bb = int(l.split()[3], 16)
        be = bb + int(l.split()[5], 16)


def check_text (addrs):
    addr = int(addrs, 16)
    return (tb <= addr) and (addr < te)

def check_text_sec (addrs):
    addr = int(addrs, 16)
    return (tb <= addr) and (addr < te)

def check_data (addrs):
    addr = int(addrs, 16)
    c1 = (rdb <= addr) and (addr < rde)
    c2 = (db <= addr) and (addr < de)
    c3 = (bb <= addr) and (addr < be)
    return c1 or c2 or c3

def check_data1 (l):
    c1 = ".rodata" in l
    c2 = ".data" in l
    c3 = ".bss" in l
    return c1 or c2 or c3

def check_text1 (l):
    c = ".text" in l
    return c

def check_data_bss_rodata_sec (addrs):
    addr = int(addrs, 16)
    c1 = (rdb <= addr) and (addr < rde)
    c2 = (db <= addr) and (addr < de)
    c3 = (bb <= addr) and (addr < be)
    return c1 or c2 or c3


is_text = False
data_addrs = []
text_addrs = []
for i in range(len(lines2)):
    l = lines2[i]
    if is_text == True:
        if "386" in l and "32" in l:
            a = l.split()[3]
            if (check_data_bss_rodata_sec (a)) == True:
                a1 = l.split()[0]
                data_addrs.append(a1)
            if (check_text_sec (a)) == True:
                a1 = l.split()[0]
                if (check_text_sec (a1)) == True:
                    text_addrs.append(a1)
    elif '.rel.text' in l:
        is_text = True
    elif 'Relocation section' in l:
        is_text = False

#print text_addrs

syms = []
for i in range(len(lines1)):
    l = lines1[i]
    if "R_386_" in l and not "PC32" in l:
        lp = lines1[i-1]
        if not '0x' in lp: 
            lp = lines1[i-2]
            if not '0x' in lp: 
                lp = lines1[i-3]
        a = lp.split(':')[0]
        a1 = '0' + l.split(':')[0].strip()
        if (check_data1 (l)) == True:
            syms.append((a,'c2d'))
        elif (check_text1 (l)) == True:
            syms.append((a,'c2c'))
        elif a1 in text_addrs:
            syms.append((a,'c2c'))
        elif a1 in data_addrs:
            syms.append((a,'c2d'))

is_data = False
is_rodata = False
is_text = False
for i in range(len(lines2)):
    l = lines2[i]
    if '.rel.data' in l:
        is_data = True
        is_rodata = False
        is_text = False
    elif '.rel.rodata' in l:
        is_rodata = True
        is_data = False
        is_text = False
    elif '.rel.text' in l:
        is_rodata = False
        is_data = False
        is_text = True
    elif "Relocation section" in l:
        is_rodata = False
        is_data = False
        is_text = False
    elif is_text == True:
        if "386" in l:
            a = l.split()[3]
            if (check_text (a)) == True and not ("PC32" in l) or ".text" in l:
                #syms.append((a,'c2c'))
                continue
            elif (check_data (a)) == True:
                #syms.append((a,'c2d'))
                continue
            else: # c to other sections
                syms.append((a,'c2o'))
    if is_data == True:
        if "386" in l:
            a = l.split()[0]
            if (check_text1 (l)) == True:
                syms.append((a,'d2c'))
            elif (check_data1 (l)) == True:
                syms.append((a,'d2d'))
            else:
                a1 = l.split()[3]
                if (check_data (a1)) == True:
                    syms.append((a,'d2d'))
                elif (check_text (a1)) == True:
                    syms.append((a,'d2c'))
                else:
                    print a + " error"

    if is_rodata == True:
        if "386" in l:
            a = l.split()[0]
            if (check_text1 (l)) == True:
                syms.append((a,'d2c'))
            elif (check_data1 (l)) == True:
                syms.append((a,'d2d'))
            else:
                a1 = l.split()[3]
                if (check_data (a1)) == True:
                    syms.append((a,'d2d'))
                elif (check_text (a1)) == True:
                    syms.append((a,'d2c'))
                else:
                    print a + " error"

      

syms_l = map(lambda l : l[0] + " " + l[1] + "\n", syms)

# dump symbols
fn3 = fn + '.symtbl'
with open(fn3, 'w') as f:
    f.writelines(syms_l)
