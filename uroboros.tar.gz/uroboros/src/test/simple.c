#include <stdio.h>  /* for printf */
#include <string.h> /* for strchr */

int foo1(int a)
{
	int b = a + 1;
	printf("%d\n",b);
	return b;
}


int foo(int aa)
{
	int r = foo1(aa);

	int c =  r + 2;

	printf("%d\n",c);
	return c;

}

 
double cm_to_inches(double cm) {
	return cm / 2.54;
}
	double (*func1)(double)            = cm_to_inches;
	//char * (*func2)(const char *, int) = strchr;
 
int foo3(void) {
	//printf("%f %s", func1(15.0), func2("Wikipedia", 'i'));

	printf("%f\n", func1(15.0));
        return 0;
}

int main()
{
	printf("%d\n",123);
	int t = foo(123);
	printf("%d\n",t);
        foo3();
     
	return 0;
}
