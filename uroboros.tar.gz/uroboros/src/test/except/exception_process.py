import re

lines = []

with open('gcctb') as f:
	lines = f.readlines()

lines = lines[2:-2]

for i in range(len(lines)):
	l = lines[i]
	if ";" in l:
		lines[i] = l.split(';')[0]


text_b = 0
text_e = 0

with open('text_sec.info') as f:
	l = f.readlines()[0]
	text_b = int(l.split()[1], 16)
	text_e = int(l.split()[3], 16) + text_b

tbl_b = int(lines[0].split()[0],16)
tbl_e = int(lines[-1].split()[0],16)


text_labels = []

local_labels = []

def update_label1 (d):
	if d >= text_b and d < text_e:
		text_labels.append("S_0x"+hex(d)[2:].upper())
		return True
	elif d >= tbl_b and d < tbl_e:
		local_labels.append(d)
		return True
	else:
		return False


def update_label2 (s):
	addr = s.split('_')[1]
	update_label1(int(addr,16))
	return "S_0x"+addr.upper()

# addr, type, cont
parsed_ls = []

def pat_match1(s):
	pat1 = r'[0-9A-F]{7}h'
	ms = re.search(pat1, s)
	if ms:
		msd = int(ms.group(0)[:-1], 16)
		if update_label1(msd):
			s1 = "S_0x"+hex(msd)[2:].upper()
			s = s.replace(ms.group(0),s1)
	return s

def pat_match2(s):
	pat2 = r'[a-z]+_[0-9A-F]+'
	ms = re.search(pat2, s)
	if ms:
		if "S_" not in ms.group(0):
			t = ms.group(0)
		elif "S_" not in ms.group(1):
			t = ms.group(1)
		else:
			print "failed : "+s
		s1 = update_label2(t)
		s = s.replace(t,s1)

def parse(s):
	if "@@CXXABI" in s:
		return s.split('@')
	else:
		s1 = pat_match1(s)
		s2 = pat_match1(s1)
		return s2

def typ_trans(t):
	if t == 'dd':
		return ".long"
	elif t == 'db':
		return ".byte"
	else:
		print "unsupported type trans"

for l in lines:
	l = l.replace('offset','')
	items = l.strip().split()
	# only have address
	if len(items) == 1: 
		continue
	addr = int(items[0],16)
	if "dd" == items[1] or "db" == items[1]:
		label = ""
		typ = items[1]
		cont = parse(' '.join(items[2:]))
	else:
		label = ""
		typ = items[2]
		cont = parse(' '.join(items[3:]))
	parsed_ls.append([addr,label,typ,cont])

for i in range(0,len(parsed_ls)):
	l = parsed_ls[i]
	if l[0] in local_labels:
		l[1] = "S_0x"+hex(l[0])[2:].upper()
	l[2] == typ_trans(l[2])
	parsed_ls[i] = l

print parsed_ls

print text_labels

print local_labels
