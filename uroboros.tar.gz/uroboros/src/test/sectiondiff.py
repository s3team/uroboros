import sys, os, subprocess
from StringIO import StringIO

options = sys.argv[1]
#section_name = sys.argv[2]
elf_file1 = sys.argv[2]
elf_file2 = sys.argv[3]

#options = sys.argv[1]
section_name = ".text"
#elf_file1 = "ln"
#elf_file2 = "ln_new"


def dumpsection(section_name, elf_file):
    lines = []

    dumpfilename = elf_file + "_dump.txt"
    os.system("objdump -s -j " + section_name + " " + elf_file + " > " + dumpfilename)

    with open(dumpfilename, 'r') as f:
        lines = f.read().splitlines()

    lines = lines[4:]

    length = len(lines)

    def helper(index):
        if index == length - 1:
            items = lines[index].split()
            l = len(items)
            return "".join(items[1:l - 1])
        else:
            items = lines[index].split()
            return "".join(items[1:5])
    lines = map(lambda index: helper(index), range(len(lines)))

    with open(dumpfilename, "w") as f:
        def helper(line):
            f.write(line)
        map(lambda line: helper(line), lines)


def md5(elf_file1, elf_file2):
    dumpfilename1 = elf_file1 + "_dump.txt"
    dumpfilename2 = elf_file2 + "_dump.txt"

    md5_1 = os.popen("md5sum " + dumpfilename1).read()
    md5_2 = os.popen("md5sum " + dumpfilename2).read()

    print "MD5:"
    print elf_file1 + " : " + md5_1.split()[0]
    print elf_file2 + " : " + md5_2.split()[0]


def countdiff(elf_file1, elf_file2):
    dumpfilename1 = elf_file1 + "_dump.txt"
    dumpfilename2 = elf_file2 + "_dump.txt"

    content1 = ""
    content2 = ""

    with open(dumpfilename1) as f:
        content1 = f.read()

    with open(dumpfilename2) as f:
        content2 = f.read()

    size1 = len(content1)
    size2 = len(content2)
    countdiff.counter = 0

    if size2 > size1:
        countdiff.counter = size2 - size1

    if size1 > size2:
	size1 = size2
        countdiff.counter = size1 - size2

    def helper(index):
        if content1[index] != content2[index]:
            countdiff.counter = countdiff.counter + 1
    map(lambda i: helper(i), range(size1))

    diff = countdiff.counter / float(size1)
    print "diff : " + str(diff*100)

def ROPgadgetsDiff(elf_file1, elf_file2):
    rop1 = subprocess.check_output(["ROPgadget", "./"+elf_file1],
    stderr=subprocess.STDOUT)

    rop2 = subprocess.check_output(["ROPgadget", "./"+elf_file2],
    stderr=subprocess.STDOUT)
    
    rop1 = rop1.splitlines()[2:]
    rop2 = rop2.splitlines()[2:]

    ROPgadgetsDiff.rop1_addrs = []
    ROPgadgetsDiff.rop2_addrs = []

    for line in rop1:
	if line.strip() == "":
	    break
	ROPgadgetsDiff.rop1_addrs.append(line.split()[0][:-1])
	
    for line in rop2:
	if line.strip() == "":
	    break
	ROPgadgetsDiff.rop2_addrs.append(line.split()[0][:-1])


    ROPgadgetsDiff.counter = 0
    totalgadgets = len(ROPgadgetsDiff.rop1_addrs)

    if totalgadgets == 0:
        print "no gadgets found!"
    else:
	def helper(addr):
	    if addr not in ROPgadgetsDiff.rop2_addrs:
		ROPgadgetsDiff.counter = ROPgadgetsDiff.counter + 1
	map(lambda line: helper(line), ROPgadgetsDiff.rop1_addrs)

    	print "gadgets changed : " + str(ROPgadgetsDiff.counter/float(totalgadgets)*100)

def SizeDiff(elf_file1, elf_file2):
    #-rwxrwxr-x 1 shuai shuai 350918 Feb  6 22:37 ls
    size1 = os.popen("ls -l " + elf_file1).read().split()[4]
    size2 = os.popen("ls -l " + elf_file2).read().split()[4]
    size1 = int(size1)
    size2 = int(size2)

    print "size diff : " + str(size2/float(size1)*100)
    

dumpsection(section_name, elf_file1)
dumpsection(section_name, elf_file2)

if options == "-m":
    md5(elf_file1, elf_file2)

if options == "-d":
    countdiff(elf_file1, elf_file2)

if options == "-r":
    ROPgadgetsDiff(elf_file1, elf_file2)

if options == "-s":
    SizeDiff(elf_file1, elf_file2)

filename = elf_file1 + "_dump.txt"
os.system("rm " + filename)
filename = elf_file2 + "_dump.txt"
os.system("rm " + filename)
