{ time ./$1 50m.img ; } 2>> runtime.data
