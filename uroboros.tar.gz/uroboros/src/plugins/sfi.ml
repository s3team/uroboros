(* align control transfer destinations *)
module Aligner = struct

    open Ail_utils

    let align_macro =
      ".p2align 4\n"

    (* il update list  *)
    let il_update = ref []


    let insert_macro i m =
      let label = get_label i in
      update_label i (m ^ label)


    let gen_padding_num d =
      16 - d land 0x0000000f

    let gen_align_instr loc n =
      let module IU = Instr_utils in
      match n with
        | 0 | 16 -> []
        | 1
        | 2
        | 3 ->
           let nop = IU.gen_nop loc in
           Array.make n nop |> Array.to_list
        | 4 ->
           let lea = IU.gen_4_lea loc in [lea]
        | 5 ->
           let nop = IU.gen_nop loc in
           let lea = IU.gen_4_lea loc in [nop; lea]
        | 6 ->
           let lea = IU.gen_6_lea loc in [lea]
        | 7 ->
           let nop = IU.gen_nop loc in
           let lea = IU.gen_6_lea loc in [nop; lea]
        | _ when n < 16 ->
           let nop = IU.gen_nop loc in
           Array.make n nop |> Array.to_list
        | _ ->
           failwith @@ (string_of_int n) ^ "undefined value"


    let insert_instrs i il =
      let open Instr_utils in
      let l = get_loc i in
      let il' = List.map (fun i -> (i, l, INSERT, "")) il in
      il_update :=  il' @ !il_update;
      i


    (* TODO: call instruction *)
    let update_call_align i =
      get_addr i
      |> gen_padding_num
      |> gen_align_instr @@ get_loc i
      |> insert_instrs i


    let non_call_align il =
      let module IU = Instr_utils in
      let module OU = Opcode_utils in
      let aux i =
        match IU.is_control_des i with
        | true ->
           begin
             match OU.is_call @@ get_op i with
               (*  | true -> update_call_align i *)
               | true -> insert_macro i align_macro
               | false -> insert_macro i align_macro
           end
        | false -> i
      in
      il |> List.rev_map aux |> List.rev


   let call_align il =
      let module IU = Instr_utils in
      !il_update
      |> IU.sort_il_update
      |> IU.update_instrs_infront il


   let align il =
     non_call_align il |> call_align


end


module Instrument_Mem = struct

    open Ail_utils

    (* il update list  *)
    let il_update = ref []


    let set_update i =
      let open Instr_utils in
      let l = get_loc i in
      il_update := (i, l, INSERT, "") :: !il_update


    (* remember we have to remove the label on the memory write operation, and
    move it to the sandboxing instruction *)
    let eliminate_label i =
      update_label i ""


    let sandboxing_template loc e =
      (* TODO: well, how to choose the and number *)
      let open Type in
      (* usually, for 32-bit programs
              the memory write on global variables ranges 0x8050000 ~ 0x8060000
              the memory write on heap   variables ranges 0x9900000 ~ 0x9950000
              the memory write on stack  variables ranges 0xffe0000 ~ 0xffff000
       *)
      TripleInstr (CommonOP (Logic ANDL), e, Const (Normal 0xffffffff), loc, None)
      |> set_update


    let gen_sandboxing_instr i t =
      let open Type in
      match t with
      (* TODO: stack operation *)
      | SINGLE_WRITE -> i
      | DOUBLE_WRITE -> i
      | TRIPLE_WRITE ->
         begin
           sandboxing_template (get_loc i) (get_exp_1 i);
           eliminate_label i
         end

   let insert_sandboxing_instrs il =
      let module IU = Instr_utils in
      !il_update
      |> IU.sort_il_update
      |> IU.update_instrs_infront il

    let instrument il =
      let open Cfg_visitor in
      let visit i t =
        (* pre-process ? *)
        gen_sandboxing_instr i t
      in
      map_mem_write visit il
      |> insert_sandboxing_instrs


end


module Instrument_Control = struct

    open Ail_utils

    (* il update list  *)
    let il_update = ref []


    let set_update i =
      let open Instr_utils in
      let l = get_loc i in
      il_update := (i, l, INSERT, "") :: !il_update


    (* remember we have to remove the label on the jmp operation, and move it
    to the sandboxing instruction *)
    let eliminate_label i =
      update_label i ""


    let sandboxing_template_indirect loc e =
      let open Type in
      let e =
      match e with
      | Symbol (StarDes e') -> e'
      | _ -> e
      in
      (*
            usually, the text section, plus plt, got, the range would be
                    ranges 0x8048000 ~ 0x8060000
       *)
      TripleInstr (CommonOP (Logic ANDL), e, Const (Normal 0xffffffff), loc, None)
      |> set_update


    let sandboxing_template_ret loc =
      let open Type in
      TripleInstr (CommonOP (Logic ANDL), Ptr (UnOP (StackReg ESP)), Const (Normal 0xffffffff), loc, None)
      |> set_update


    let gen_sandboxing_ret i =
      get_loc i |> sandboxing_template_ret;
      eliminate_label i


    let gen_sandboxing_indirect i =
      let l = get_loc i in
      let e = get_exp_1 i in
      sandboxing_template_indirect l e;
      eliminate_label i


   let insert_sandboxing_instrs il =
      let module IU = Instr_utils in
      !il_update
      |> IU.sort_il_update
      |> IU.update_instrs_infront il


    let instrument il =
      let open Cfg_visitor in
      let open Type in
      let visit i t =
        match t with
        | RET_TYPE ->
           gen_sandboxing_ret i
        | INDIRECT ->
           gen_sandboxing_indirect i
        | _ -> i
      in
      map_jmp visit il
      |> insert_sandboxing_instrs


end



module SFI = struct

  (* this plugin implements a SFI on CISC architecture *)
  (* please refer to this paper about the algorithm
http://people.csail.mit.edu/smcc/projects/pittsfield/pubs/usenix-sec-2006/pittsfield-usenix2006.pdf
   *)
  (* INPUT:
        the original binary
     OUTPUT:
        SFIed binary
   *)

  (*
   steps:
     1. align jump destinations to 16-byte boundaries.
     2. instrument memory writing operations.
     2. instrument (indirect) jump operation.
     3. optimization 1.
     5. optimization 2.
     6. optimization XXX.

   *)


  (* alignment  *)
  let procedure_one instrs =
    let module A = Aligner in
    print_endline "SFI procedure one";
    A.align instrs


  (* sandboxing memory write *)
  let procedure_two instrs =
    let module I = Instrument_Mem in
    print_endline "SFI procedure two";
    I.instrument instrs


  (* sandboxing (indirect) control transfer *)
  let procedure_three instrs =
    let module I = Instrument_Control in
    print_endline "SFI procedure three";
    I.instrument instrs


  let sfi instrs =
    (*
    procedure_one instrs
    |> procedure_two
     *)
    instrs
    |> procedure_three

end
