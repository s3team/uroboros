# this script is used for iterative test, for instance we iteratively produce 50 binaries based on the original one, and put them inside one folder

import os, sys


def test_once(f, i):
   print ("########## iteration round "+str(i+1) + " begin ! ###########")
   os.system("python main_discover.py " + f)
   os.system("python useless_func_discover.py " + f)
   os.system("strip " + f)
   os.system("rm final_data.s")
   os.system("./init.native " + f)
   os.system("python post_process_data.py")
   os.system('cat final_data.s >> final.s')
   os.system("python compile_process.py")
   #os.system("python instr_prune.py " + f + " " + str(i+1))
   os.system("g++ final.s -g -lm -lrt -lpthread -m32")
   os.system("cp a.out " + f)
   os.system("cp " + f + " test_folder_"+f+"/"+f+"."+str(i+1))
   print ("########## iteration round "+str(i+1) + " finish ! ##########")
   print ""

f = sys.argv[1]
c = sys.argv[2]

os.system('rm -rf test_folder_'+f)

os.system('mkdir test_folder_'+f)

os.system('cp test/'+f + " .")

os.system("strip " + f)
os.system('rm useless_func.info')
os.system("rm final_data.s")

print ("########## iteration round 1 begin ! ###########")
os.system("python main_discover.py " + f)
os.system("./init.native " + f)
os.system("python post_process_data.py")
os.system('cat final_data.s >> final.s')
os.system("python compile_process.py")
#os.system("python instr_prune.py " + f + " " + str(i+1))
os.system("g++ final.s -g -lm -lrt -lpthread -m32")
os.system("cp a.out " + f)
os.system("cp " + f + " test_folder_"+f+"/"+f+".1")
print ("########## iteration round 1 finished ! ###########")
print ""

for i in range(1,int(c)):
    test_once(f, i)

#os.system('cp 50m.img test_folder_'+f + "/50m.img")
os.system('cp multiple_bin_test.py test_folder_'+f + "/multiple_bin_test.py")
os.system('cp run.sh test_folder_'+f + "/run.sh")
os.system('cp calc.py test_folder_'+f + "/calc.py")
os.system('cp test/'+f+' test_folder_'+f + "/"+f+'.0')
