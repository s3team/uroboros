class my_class  =

let test1 s =
    s in

let test = function
| 1 -> print_int 1
| 2 -> print_int 2
| _ -> print_int 3 in


object(self)

end

