open Ail_utils
open Dataflow
open Type
open Pp_print


(* liveness
    Data Representation = keep one bit for each register
    gen                  : any use (not def before in the same BB)
    kill                 : any def before any use in bb
    transfer function    : in = (out-kill) U gen
    confluence op        : out = U in_s
    start state          : out_final = {}
 *)

class liveness =

object(self)
  inherit dataflow

  (* returns the live registers of a given instruction.
the information is stored ina a bitstring, indexed by register
number. A set bit means the register is live.
   *)
  method getLive bb insn =
    assert(solved);

    let cur_set = self#getOutSet bb in

    let bbl = bb_instrs bb in
    let bbl_rev = List.rev bbl_rev in
    let aux cur_set i =

      let def_mask = get_reg_defmask i true in
      let use_mask = get_reg_usemask i true in
      self#transfer cur_set use_mask def_mask in

    List.fold_left aux current_set bbl_rev


  (* gen set for liveness: the set of variables used in bb before any assignment *)
  method createGenSet bb =
    let current_set = create_bitstring num_bits in
    let bbl = bb_instrs bb in
    let bbl_rev = List.rev bbl_rev in
    let aux cur_set i =
      let def_mask = get_reg_defmask insn true in
      let use_mask = get_reg_usemask insn true in
      self#transfer cur_set use_mask def_mask in
    List.fold_left aux current_set bbl_rev


  (* kill set for liveness: the set of variables used in bb before any use *)
  method createKillSet bb =
    let current_set = create_bitstring num_bits in
    let bbl = bb_instrs bb in
    let bbl_rev = List.rev bbl_rev in
    let aux cur_set i =
      let def_mask = get_reg_defmask insn true in
      let use_mask = get_reg_usemask insn true in
      self#transfer cur_set use_mask def_mask in
    List.fold_left aux current_set bbl_rev


  method init =
    direction <- Backward;
    num_bits = 256;

  initializer
    self#init;

end
