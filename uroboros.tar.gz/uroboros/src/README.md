# Overview

Uroboros is a platform for binary disassembly and transformation. It is mainly
written in OCaml.

# Version

0.1 (pre-release version)


# Installation

Uroboros leverages the following GNU utilities, make sure they are installed on
your platform.

1. objdump 2.22
2. readelf 2.22
3. awk     3.18

Uroboros is built by OCaml compiler version 4.01.0, and it relies on libraries as
follows:

1. deriving 0.7
2. ocamlfind 1.5.5
3. parmap  1.0-rc6
4. batteries 2.3.1
6. ocamlbuild 4.01.0

Our developing environment is 64-bit Ubuntu 12.0.4. We encourage users to use
the same OS to install, as GNU utilities and Python are installed by default.
The OCaml compiler and libraries should be easily installed through
[opam](https://opam.ocaml.org/).

## Build

Once you installed all the requirements, execute the command below at ./src folder.

    ./build

# Use Uroboros to disassemble binaries

Currently, Uroboros takes 64-bit and 32-bit ELF executable binaries as the
input.

To use Uroboros for disassembling:

    python uroboros.py /home/szw175/spec_64/bzip


The disassembled output can be found at current dicrectory, named,
**final.s**. Uroboros will also assemble it back into an executable, **a.out**.

Python script uroboros.py provides multiple options to manipulate the
disassembling process.

1. -i (iteration):

The disassemble-reassemble process can be iterated for
multiple times. For example.

    python uroboros.py /home/szw175/spec_64/bzip -i 500

2. -k (keep):

For multiple iterations of processing, this option will create a folder to
store the assembly code and binary generated from each iteration.

    python uroboros.py /home/szw175/spec_64/bzip -i 500 -k

A subfolder will be created in ./src folder, with input binary name and
timestamp. For example:

    test_fold_bzip_2015-08-31_11:11:50

3. -a (assumption):

This option configures the three symbolization assumptions proposed in the
paper [1]. Note that in current version, the first assumption (**n-byte
alignment**) are set by default. The other two assumptions can be set by users.

Assumption two:

    python uroboros.py /home/szw175/spec_64/bzip -a 2

Note that by accepting this assumption, we need to put data sections (.data,
.rodata and .bss) to its original starting addresses. Linker scripts can be
used during reassembling. For exmaple:

    gcc -Tld_gobmk.sty final.s

Users may write their own linker script, some examples are given at
*./src/ld_script* folder.


Assumption three:

    python uroboros.py /home/szw175/spec_64/bzip -a 3


This assumption requires to know the function starting addresses, currently in
order to obtain this information, Uroboros need to take **unstripped** binaries
as input. The function starting address information is obtained from the input;
we then strip the intput before disassembling.


As discussed in our paper [1], assumptions can be used together.

    python uroboros.py /home/szw175/spec_64/bzip -a 3 -a 2


# Use Uroboros to instrument binaries

Instrumentation tools process the internal data structure of Uroboros. We
present multiple examples at *./src/plugins* folder. You may start from the
**mem_write.ml**, which instrument every memory write operation with some
logging code.

Currently, in order to register instrumentation code, users need to add some
code at *./src/ail.ml*, starting from line 317. For example, in order to
resgiter the "mem_write" tool, three lines of code need to be added as follows:

    let open Mem_write in
    let module MW = Mem_write in
    let il' = MW.process il in

We will provide better way to register instrumentation code when releasing.


Hope it works, otherwise please let me know.

Shuai Wang szw175@ist.psu.edu


[1] Reassembleable Disassembling, by Shuai Wang, Pei Wang, and Dinghao Wu. In
Proceedings of the 24th USENIX Security Symposium, Washington, D.C., August 12-14, 2015.
