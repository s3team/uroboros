#!/bin/bash
c=20
N=(0 1 50 100 500 1000)
for n in ${N[@]}; do
    i=0
    a="0.0"
    while [ $i -le $c ]; do
        i=$[$i+1]
        t=$({ /usr/bin/time -f "%S %U" ./hmmer_spec.$n leng100.hmm > /dev/null; } 2>&1)
	read -a tt <<< "$t"
        a=$(bc <<< "$a+${tt[0]}+${tt[1]}")
    done
    bc <<< "scale=4;$a/$c"
done
