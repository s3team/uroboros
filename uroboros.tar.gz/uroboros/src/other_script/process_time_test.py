import os

time_map = {}

def process(b, sl, c):
    user = 0
    sys = 0
    c1 = c
    t1 = []
    base = 0
    total = 0
    for l in sl:
        if "user" in l:
            t = l.split('m')[1].split('s')[0]
            user = float(t)
        if "sys" in l:
            t = l.split('m')[1].split('s')[0]
            sys = float(t)
            total += user + sys
            c1 -= 1
            t1.append(total)
    if c1 == 0:
        total = total/10
        #print b + " : " + str(total)
        time_map[b] = total
    else:
        print "error " + b 

class cd:
    def __init__(self, newPath):
        self.newPath = os.path.expanduser(newPath)

    def __enter__(self):
        self.savedPath = os.getcwd()
        os.chdir(self.newPath)

    def __exit__(self, etype, value, traceback):
        os.chdir(self.savedPath)

#bs = os.listdir('./test/coreutils_32_normal')
#bs = os.listdir('./test/spec_32_normal')
bs = os.listdir('./test/real_32_normal')

print len(bs)

bs = sorted(bs)

for b in bs:
    #if b not in ['gcc','h264ref','gobmk','hmmer']:
    #if b not in ['gobmk']:
    #    continue
    os.system('rm process_time.res')
    for i in range(10):
        os.system('cp test/real_32_normal/'+b + " .")
        os.system('bash run.sh '+b)
    
    lines = []
    with open('process_time.res') as f:
        lines = f.readlines()
    
    process(b, lines, 10)


print time_map


for k,v in time_map.iteritems():
    print '| ' + k + ' | ' + str(v) + ' |'

