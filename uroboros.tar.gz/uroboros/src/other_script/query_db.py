# check two folders based on two different diffing strategies.

# base 
# check bin_0_vs_bin_50_BinDiff

# relative
# check bin_50_vs_bin_100_BinDiff

import sqlite3 as lite
import sys, os

p = sys.argv[1]

class cd:
    def __init__(self, newPath):
        self.newPath = os.path.expanduser(newPath)

    def __enter__(self):
        self.savedPath = os.getcwd()
        os.chdir(self.newPath)

    def __exit__(self, etype, value, traceback):
        os.chdir(self.savedPath)


def check(b1, b2):
    fn = b1 + "_vs_"+b2 + ".BinDiff"
    #print "processing " + fn

    con = None
    
    total_instr = 0
    matched_instr = 0
    
    try:
        con = lite.connect(fn)
        cur = con.cursor()    
        cur.execute('SELECT * FROM file')
        
        data = cur.fetchone()
        
        #print "instruction number : %s" % data[-2]
        total_instr = data[-2]
      
        cur.execute('SELECT count(*) FROM instruction')
        data = cur.fetchone()
        
        #print "instruction table size : %s" % data
        matched_instr = data[0]
        
    except lite.Error, e:
        print "Error %s:" % e.args[0]
        sys.exit(1)
        
    finally:
        if con:
            con.close()
    
    #print "macthed percentage " + str(matched_instr/float(total_instr))
    print str(total_instr) + " " + str(matched_instr) + " " + str(matched_instr/float(total_instr))


#####################  base ##########################

with cd(p+'/base/'):
    print "base diffing data"
    
    bn = 'bzip2_base_i386-m32-gcc42-nn_'
    bn0 = bn+'0'
    
    for i in range(50,1050,50):
        bnr = bn + str(i)
    
        check(bn0, bnr)
    

################## relative ################################

with cd(p+'/relative/'):
    print "base diffing data"
    
    bn = 'bzip2_base_i386-m32-gcc42-nn_'
    
    for i in range(0,1000,50):
        bn1 = bn + str(i)
        bn2 = bn + str(i+50)
    
        check(bn1, bn2)


















