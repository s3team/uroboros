import os, sys, operator



#def size_dump(fn):
#    os.system('ls -l '+path +"/" + fn  + " | grep "+fn+" >> "+ path +"/size.data")

def performance_dump(fn, c):
    for i in range(c):
        print "test " + fn + " " +str(i)
        os.system('bash run.sh '+fn) 

def size_process(sl, base):
    res = []
    for l in sl:
        t = l.split()[4]
	t1 = (int(t) - base)/float(base)
        res.append(str(t1*100)+'\n')

    return res 

def performance_process(sl, c):
    res = []
    user = 0
    sys = 0
    c1 = c
    t1 = []
    is_first = True
    base = 0
    pattern = r"m(/d+/./d+)s"
    for l in sl:
        if "user" in l:
            #m = re.search(pattern, l)
            t = l.split('m')[1].split('s')[0]
            user = float(t)
        if "sys" in l:
            #m = re.search(pattern, l)
            t = l.split('m')[1].split('s')[0]
            sys = float(t)
            total = user + sys
            c1 -= 1
            t1.append(total)
            if c1 == 0:
                t1.sort()
                t1 = t1
                total = reduce(operator.add, t1, 0)
                total = total/float(c)
                res.append(str(total)+"\n")
                c1 = c
                t1 = []
            else:
                continue
    return res 

fn = sys.argv[1]
c = sys.argv[2]
#path = sys.argv[3]

#os.system('strip '+ path + "/*")

step = 50
performance_time = 30

#os.system('rm '+ path + '/size.data')
os.system('rm runtime.data')

for i in range(0, int(c)+1, step):
    fn1 = fn+"."+str(i)
#    size_dump(fn1)
    performance_dump(fn1, performance_time)

#lines = []

#with open(path + '/size.data') as f:
    #lines = f.readlines()

#base = int(lines[0].split()[4])

#r1 = size_process(lines, base)

#with open(path + '/size.res', 'w') as f:
#    f.writelines(r1)


with open('runtime.data') as f:
    lines = f.readlines()

r2 = performance_process(lines, performance_time)

base = float(r2[0])

res = []

for i in range(1,len(r2)):
    t = float(r2[i])
    t1 = (t-base)/base
    res.append(str(t1*100) +'\n')

with open('runtime.res', 'w') as f:
    f.writelines(res)

#os.system('python rop_base.py '+ fn + " " + str(c) + " " + path)

#os.system('python rop_base.py '+ fn + " " + str(c))

