import os

evaluate_path = '/data/ail_data/transformed_binaries/coreutils_new_opt/'
size_path = '/data/ail_data/transformed_binaries/coreutils_new_opt/evaluation_data/size_data/'
rop_path = '/data/ail_data/transformed_binaries/coreutils_new_opt/evaluation_data/rop_data/'
perf_path = '/data/ail_data/transformed_binaries/coreutils_new_opt/evaluation_data/perf_data/'

base_path = '/data/ail_data/transformed_binaries/coreutils_new_opt/'

def task (root, bn):
    name = bn

    os.chdir(root)
    os.system("python multiple_bin_test_step.py "+name+" 1000")
    os.system("cp runtime.res "+perf_path+"runtime.res."+name)
    os.chdir(base_path)

    #for file in files:
    #    print len(path)*'---', file


if __name__ == '__main__':
    bins = []
    
    with open('coreutils_list_full') as f:
        bins = f.readlines()
    
    bins = map(lambda b : b.strip(), bins)
    #print bins


    for bn in bins:
        root = "./test_folder_" + bn
        os.system("cp multiple_bin_test_step.py " + root)

        task(root, bn)
