import os, time

class cd:
    def __init__(self, newPath):
        self.newPath = os.path.expanduser(newPath)

    def __enter__(self):
        self.savedPath = os.getcwd()
        os.chdir(self.newPath)

    def __exit__(self, etype, value, traceback):
        os.chdir(self.savedPath)

bs = os.listdir('./test/coreutils_32_normal')
#bs = os.listdir('./test/real_32_normal')
#bs = os.listdir('./test/spec_32_normal')

print len(bs)

#for b in bs:
for b in ['mv','bin2','stdbuf','cp','ln']:
    if b in ['test']:
        continue
    #os.system('cp test/coreutils_32_normal/'+b + " .") 
    os.system('time ./ail -b ' + b + ' -t 1 keep')
    os.system('cp a.out ' + b)
    #time.sleep(1)

    os.system('cp '+b + " /data/ail_data/coreutils_normal/temp/coreutils-8.15/src/")

# size test!

#rs = {}
#
##os.system('mkdir test_size_real')
#os.system('mkdir test_size_coreutils')
##os.system('mkdir test_size_spec')
#
#for b in bs:
##for b in ['nl']:
#    if b in ['factor','expr','[','test']:
#        continue
#    #os.system('cp test/coreutils_32_normal/'+b + " .")
#    os.system('time ./ail -b ' + b + ' -t 1 keep')
#
#    #os.system('cp '+b + " /data/ail_data/coreutils-8.15/src")
#
#    os.system('strip a.out')
#    os.system('ls -l a.out > size.check')
#    os.system('ls -l ' + b + ' >> size.check')
#
#    with open('size.check') as f:
#        lines = f.readlines()
#        s1 = lines[0].split()[4]
#        s2 = lines[1].split()[4]
#        s1 = int(s1,16)
#        s2 = int(s2,16)
#        rs[b] = (s1-s2)/float(s2) * 100
#
#    #os.system('cp a.out test_size_spec/'+b)
#    #os.system('cp a.out test_size_real/'+b)
#    os.system('cp a.out test_size_coreutils/'+b)
#    
#for k,v in rs.iteritems():
#    print k + " | " + str(v)
