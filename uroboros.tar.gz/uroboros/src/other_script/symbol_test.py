import os


class cd:
    def __init__(self, newPath):
        self.newPath = os.path.expanduser(newPath)

    def __enter__(self):
        self.savedPath = os.getcwd()
        os.chdir(self.newPath)

    def __exit__(self, etype, value, traceback):
        os.chdir(self.savedPath)

#bs = os.listdir('./test/coreutils_32_normal')
#bs = os.listdir('./test/spec_32_normal')
bs = os.listdir('./test/spec_32_llvm_normal')

rs = [('reassemble_symbol_get_Empty.ml','k1'), ('reassemble_symbol_get_A1.ml','k2'),
               ('reassemble_symbol_get_A1_A3.ml','k3')]

print len(bs)

#for b in bs:
for b in ['gcc_base.amd64-m64-gcc42-nn']:
    #if b not in ['bin', 'bin2']:
    #    continue
    #os.system('cp test/coreutils_32_normal/'+b + " .")
    #os.system('cp test/spec_32_normal/'+b + " .")
    os.system('cp test/spec_32_llvm_normal/'+b + " .")
    os.system("readelf -S "+b+" | awk \'/data|bss|got/ {print $2,$4,$5,$6} \' > sections.info")

    lines = []
    with open('sections.info') as f:
        lines = f.readlines()

    b_rodata = "0x"
    b_data = "0x"
    for l in lines:
        if ".rodata" in l:
            b_rodata += l.split()[1]
        if ".data" in l:
            b_data += l.split()[1]

    os.system("mkdir test/symbol_results/"+b)
    os.system("cp test/symbol_get.py test/symbol_results//"+b)
    os.system("cp test/symbol_compare.py test/symbol_results//"+b)

    # update to line 366 and line 367
    for (r,k) in rs:
        lines = []
        with open(r) as f:
            # patch reassemble_symbol_get.ml
            lines = f.readlines()
            l1 = lines[522]
            l2 = lines[523]
            lines[522] = l1.split('0x')[0] + b_data + ");\n"
            lines[523] = l2.split('0x')[0] + b_rodata + ");\n"
        with open(r, 'w') as f:
            f.writelines(lines)

        os.system('cp '+r + " reassemble_symbol_get.ml")
        os.system("./build")


        # execute
        os.system('time ./ail -b '+b + " -t 1 keep")

        os.system('cp final_d2* test/symbol_results/'+b)
        os.system('cp final_c2* test/symbol_results/'+b)

        #os.system('cp test/coreutils_32_reloc/'+b + " test/symbol_results/" +b)
        #os.system('cp test/spec_32_reloc/'+b + " test/symbol_results/" +b)
        os.system('cp test/spec_32_llvm_reloc/'+b + " test/symbol_results/" +b)
        with cd('./test/symbol_results/'+b):
            os.system('python symbol_get.py ' + b)
            os.system('python symbol_compare.py ' + b + ' > ' + k)
            with open(k,'r') as f:
                t = f.read().replace('\n', '')
                if "!" in t:
                    print "watch out!"
                    #break
