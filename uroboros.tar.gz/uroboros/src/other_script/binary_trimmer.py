# this script preprocess the obtained trace after logging
# this script generates these files
#     bb_trace_sort_uniq.txt

#     bb_trace_join_sort_uniq.txt



import os


#     bb_trace_sort_uniq.txt
os.system('sort -T . trace.txt | uniq > bb_trace_sort_uniq.txt')


#     bb_trace_join_sort_uniq.txt

# 8 + 7 s  for a 8G file
os.system('head -n -1 trace.txt > trace1.txt')
os.system('tail -n +2 trace.txt > trace2.txt')

# 60s for a 8G file
os.system('paste -d" " trace1.txt trace2.txt > trace_join.txt')

# 18min  for a 8G file
os.system('sort -T . trace_join.txt | uniq > bb_trace_join_sort_uniq.txt')
