import os

class cd:
    def __init__(self, newPath):
        self.newPath = os.path.expanduser(newPath)

    def __enter__(self):
        self.savedPath = os.getcwd()
        os.chdir(self.newPath)

    def __exit__(self, etype, value, traceback):
        os.chdir(self.savedPath)

bs = os.listdir('./test/real_64')
rs = [('reassemble_symbol_get_empty.ml','1'), ('reassemble_symbol_get_A1.ml','2'),
               ('reassemble_symbol_get_A1_A3.ml','3')]

print len(bs)

#for b in bs:
#for b in ['ctags','web_server']:
for b in ['lbm_base.amd64-m64-gcc42-nn']:
    for (r,k) in rs:
      #os.system('cp test/real_64/'+b + " .")
      os.system('cp test/'+b + " .")
      print r
      os.system('cp '+r + ' reassemble_symbol_get.ml')
      os.system('./build > /dev/null')

      os.system('time ./ail -b '+b + " -t 1 keep > /dev/null")

      os.system("cp final.s final_"+k+".s")

    f1 = []
    with open('final_1.s') as f:
        f1 = f.read().replace('\n', '')

    f2 = []
    with open('final_2.s') as f:
        f2 = f.read().replace('\n', '')

    f3 = []
    with open('final_3.s') as f:
        f3 = f.read().replace('\n', '')

    #if f1 == f2 and f2 == f3:
    if f1 == f2:
        print " empty and A1 equal!"
    if f2 == f3:
        print " A1 and A1+A3 equal!"
    else:
        print "fail"
#    else:
#        print b + " failed!"
