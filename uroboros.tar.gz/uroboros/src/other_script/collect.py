import os

evaluate_path = '/data/ail_data/transformed_binaries/coreutils_new_opt/'
size_path = '/data/ail_data/transformed_binaries/coreutils_new_opt/evaluation_data/size_data/'
rop_path = '/data/ail_data/transformed_binaries/coreutils_new_opt/evaluation_data/rop_data/'
perf_path = '/data/ail_data/transformed_binaries/coreutils_new_opt/evaluation_data/perf_data/'

base_path = '/data/ail_data/transformed_binaries/coreutils_new_opt/'


def task (args):
    #bn = os.path.basename(root)
    #name = bn.split('_')[2]
    root = args[0]
    bn = args[1]
    name = bn
    if "test" in name:
        name = "test_bin"
    print name


    root1 = base_path + root[2:] 
    #os.chdir(root1)
    os.system("python " + root[2:] + "/multiple_bin_test.py "+name+" 1 " + root1)
    #os.system("cp "+root1 + "/size.res "+size_path+"size.res."+name)
    #os.system("cp "+root1 + "/rop_base.res "+rop_path+"rop_base.res."+name)
    os.system("cp "+root1 + "/runtime.res "+perf_path+"runtime.res."+name)
    #os.chdir(evaluate_path)

    #for file in files:
    #    print len(path)*'---', file


from Queue import Queue
from threading import Thread
    
class Worker(Thread):
    """Thread executing tasks from a given tasks queue"""
    def __init__(self, tasks):
        Thread.__init__(self)
        self.tasks = tasks
        self.daemon = True
        self.start()
            
    def run(self):
        while True:
            func, args, kargs = self.tasks.get()
            try:
                func(*args, **kargs)
            except Exception, e:
                print e
            finally:
                self.tasks.task_done()
        
class ThreadPool:
    """Pool of threads consuming tasks from a queue"""
    def __init__(self, num_threads):
        self.tasks = Queue(num_threads)
        for _ in range(num_threads): Worker(self.tasks)
        
    def add_task(self, func, *args, **kargs):
        """Add a task to the queue"""
        self.tasks.put((func, args, kargs))
        
    def wait_completion(self):
        """Wait for completion of all the tasks in the queue"""
        self.tasks.join()


if __name__ == '__main__':
    bins = []
    
    with open('bin_list') as f:
        bins = f.readlines()
    
    bins = map(lambda b : b.strip(), bins)
    #print bins

    from random import randrange
    from time import sleep

    pool = ThreadPool(1)

    path_list = []

    #for root, dirs, files in os.walk("."):
    for bn in bins:
        root = "./test_folder_" + bn
        #path = root.split('/')
        #print (len(path) - 1) *'---' , root
        #bn = os.path.basename(root)
        os.system("cp multiple_bin_test.py " + root)
        os.system("cp ../coreutils/test_folder_"+bn+"/run.sh " + root)
        #os.system("cp rop_base.py " + root)
        path_list.append(root)

#print path_list

    for root in path_list:
        pool.add_task(task, [root, bn])

    pool.wait_completion() 
