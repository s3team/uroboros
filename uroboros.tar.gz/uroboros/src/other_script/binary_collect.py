import os
# let's collect binaries in a step of 50.

base_name = 'bzip2_base.i386-m32-gcc42-nn.'
for i in range(0,1050,50):
    os.system("scp szw175@lrs-dwu01.ist.psu.edu:/data/ail_project/processors/AIL_16/src/test_folder_bzip2_base.i386-m32-gcc42-nn/bzip2_base.i386-m32-gcc42-nn."+str(i) + " bzip2_base_i386-m32-gcc42-nn_"+str(i) )

