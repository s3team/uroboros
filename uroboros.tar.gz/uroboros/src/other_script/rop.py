import sys, os

fn = sys.argv[1]
c = sys.argv[2]


#for i in range(0, int(c)+1):
#    os.system("ropgadget --binary "+fn+'.'+str(i) + " > rop_"+str(i)+".data")


for i in range(0, int(c)):
    res_f1 = 'rop_' + str(i) + '.data'

    lines1 = []
    with open(res_f1) as f:
        lines1 = f.readlines()

    lines1 = lines1[2:]

    total1 = lines1[-1].split(':')[1] # get the total number of rop gadgets
    total1 = int(total1.strip())

    lines1 = lines1[:-2]

    addrs1 = []
    for l in lines1:
        addrs1.append(l.split(':')[0])

######## second ########################3

    res_f2 = 'rop_' + str(i+1) + '.data'

    lines2 = []
    with open(res_f2) as f:
        lines2 = f.readlines()

    lines2 = lines2[2:]

    total2 = lines2[-1].split(':')[1] # get the total number of rop gadgets
    total2 = int(total2.strip())

    lines2 = lines2[:-2]

    addrs2 = []
    for l in lines2:
        addrs2.append(l.split(':')[0])

    count = 0

    for addr in addrs1:
        if addr in addrs2:
	    #print addr
            continue
        else:
            count += 1

    print (count/float(total1))*100
