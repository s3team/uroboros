import os, sys, operator

def size_dump(fn):
    os.system('ls -l ' + fn  + " | grep "+fn+" >> size.data")

def performance_dump(fn, c):
    for i in range(c):
        os.system('bash run.sh '+fn) 

def size_process(sl, base):
    res = []
    for l in sl:
        t = l.split()[4]
	t1 = (int(t) - base)/float(base)
        res.append(t1*100)

    return res 

def performance_process(sl, c):
    res = []
    user = 0
    sys = 0
    c1 = c
    t1 = []
    is_first = True
    base = 0
    pattern = r"m(/d+/./d+)s"
    for l in sl:
        if "user" in l:
            #m = re.search(pattern, l)
            t = l.split('m')[1].split('s')[0]
            user = float(t)
        if "sys" in l:
            #m = re.search(pattern, l)
            t = l.split('m')[1].split('s')[0]
            sys = float(t)
            total = user + sys
            c1 -= 1
            t1.append(total)
            if c1 == 0:
                t1.sort()
                t1 = t1
                total = reduce(operator.add, t1, 0)
                total = total/float(c)
                res.append(total)
                c1 = c
                t1 = []
            else:
                continue
    return res 

fn = sys.argv[1]
c = sys.argv[2]

os.system('rm size.data')
#os.system('rm runtime.data')

for i in range(int(c)+1):
    fn1 = fn+"."+str(i)
    size_dump(fn1)
#    performance_dump(fn1, 15)

lines = []

with open('size.data') as f:
    lines = f.readlines()

base = int(lines[0].split()[4])

#with open('runtime.data') as f:
#    lines = f.readlines()

r = size_process(lines, base)
#r = performance_process(lines, 15)

for i in r:
    print i
