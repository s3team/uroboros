open Visit
open Type
open Pp_print
open Ail_utils

type instr_update = SUB | INSERT

(*
This module generate code to
dump logging trace from memory to the disk
*)
module Dump_logging = struct

    (*



     void foo()
     {

     }


     *)
    let gen =
      ()

end

class logger =
  (* this plugin insert a logging procedure at the beginning of every basic block *)
  let dec_hex (s:int) : string =
    "0x"^(Printf.sprintf "%X" s) in

  object(self)

    val mutable fb_tbl = Hashtbl.create 40
    val mutable instrs_update = []
    val mutable locs_update = []

    inherit ailVisitor

    method insert_instrs_abd i l =
      instrs_update <- List.rev_append (List.rev instrs_update) [(i, l, INSERT, "")]

    method insert_instrs i l acc  =
      [(i, l, INSERT, "")] :: acc

    method sub_instrs_abd i l i' =
      let i_s = pp_print_instr i' in
      instrs_update <- List.rev_append (List.rev instrs_update) [(i, l, SUB, i_s)]

    method sub_instrs i l i' acc =
      let i_s = pp_print_instr i' in
      [(i, l, SUB, i_s)] :: acc

    method update_instrs_abd instrs =
      let same loc1 loc2 =
        loc1.loc_addr = loc2.loc_addr in
      let rec help l_u l =
        match (l_u, l) with
        | (h_u::t_u, h::t) ->
           begin
             let (i, loc1, ty, i_s) = h_u
             and loc2 = get_loc h in
             if same loc1 loc2 then
               begin
                 match ty with
                 | SUB ->
                    begin
                      let h_s = pp_print_instr h in
                      if i_s = h_s then
                        begin
                          (help t_u (i::t))
                        end
                      else
                        h::(help l_u t)
                    end
                 | INSERT ->
                    begin
                      h::(help t_u (i::t))
                    end
               end
             else
               h::(help l_u t)
           end
        | ([], l') -> l'
        | (h::t, []) ->
           begin
             failwith "error in update_instrs"
           end
      in
      help instrs_update instrs


      method update_instrs instrs =
        let same loc1 loc2 =
          loc1.loc_addr = loc2.loc_addr in
        let rec help l_u l acc =
          match (l_u, l) with
          | (h_u::t_u, h::t) ->
            begin
              let (i, loc1, ty, i_s) = h_u
              and loc2 = get_loc h in
                if same loc1 loc2 then
                  begin
                    match ty with
                    | SUB ->
                       begin
                        let h_s = pp_print_instr h in
                        if i_s = h_s then
                            (help t_u (i::t) acc)
                        else
                          help l_u t (h::acc)
                      end
                    | INSERT ->
                        help t_u (h::t) (i::acc)
                  end
                else
                  help l_u t (h::acc)
            end
          | ([], l') -> List.rev_append acc l'
          | (h::t, []) ->
            begin
              failwith "error in update_instrs"
            end
        in
          help instrs_update instrs []





    (*get all the instructions within one basic block as a list*)
    method bb_instrs b =
      let bloc = b.bblock_begin_loc
      and eloc = b.bblock_end_loc in
      let rec help il acc =
        match il with
        | h::t ->
           begin
             let loc = get_loc h in
             if loc.loc_addr >= bloc.loc_addr &&
                  loc.loc_addr <= eloc.loc_addr then
               help t (h::acc)
             else help t acc
           end
        | [] -> List.rev acc in
      help instrs []

    method update_current_bb_2 b =
      let obtain_addr iloc =
        let a = iloc.loc_addr in
         a 
      in
      let build_stub b =
        let n = b.bblock_name in
        n ^ "_stub"
      in
      let bil = self#bb_instrs b in
      (* TODO: we can log bn; or we can do it in a better way *)
      let bn = b.bblock_name in
      let i = List.nth bil 0 in
      let iloc = get_loc i in
      let iloc' = {iloc with loc_label = ""} in
      let addr' = obtain_addr iloc in
      let sn = build_stub b in
      let i1 = DoubleInstr (StackOP PUSH, Reg (CommonReg EAX), iloc, None) in
      let i2 = SingleInstr (StackOP PUSHF, iloc', None) in
      let i3 = TripleInstr (CommonOP (Assign MOVL), Reg (CommonReg EAX), Label "index", iloc', None) in
      let i4 = TripleInstr (CommonOP (Assign MOVL),
                            Ptr (JmpTable_PLUS_S ("buf", CommonReg EAX, 4)),
                            Const (Normal addr'), iloc', None) in
      (* add $1, %eax   *)
      let i5 = TripleInstr (CommonOP (Arithm ADD), Reg (CommonReg EAX), Const (Normal 1), iloc', None) in
      let i6 = TripleInstr (CommonOP (Compare CMP), Reg (CommonReg EAX), Const (Normal 4194304), iloc', None) in
      let i7 = DoubleInstr (ControlOP (Jump JLE), Label sn, iloc', None) in
      let i8 = TripleInstr (CommonOP (Assign MOVL), Reg (CommonReg EAX),
                            Const (Normal 0), iloc', None) in
      let i9 = TripleInstr (CommonOP (Assign MOVL), Label "index", Reg (CommonReg EAX),
                            {iloc' with loc_label = sn ^ ":"}, None) in
      let i10 = SingleInstr (StackOP POPF, iloc', None) in
      let i11 = DoubleInstr (StackOP POP, Reg (CommonReg EAX), iloc', None) in
      let i' = set_loc i iloc' in
      self#insert_instrs i1 iloc;
      self#insert_instrs i2 iloc;
      self#insert_instrs i3 iloc;
      self#insert_instrs i4 iloc;
      self#insert_instrs i5 iloc;
      self#insert_instrs i6 iloc;
      self#insert_instrs i7 iloc;
      self#insert_instrs i8 iloc;
      self#insert_instrs i9 iloc;
      self#insert_instrs i10 iloc;
      self#insert_instrs i11 iloc;
      self#sub_instrs i' iloc i

    (* this method does not need the store/reuse of flags.. *)
    method update_current_bb acc b =
      let obtain_addr iloc =
        let a = iloc.loc_addr in
         a
      in
      let build_stub b =
        let n = b.bblock_name in
        n ^ "_stub"
      in
      let bil = self#bb_instrs b in
      (* TODO: we can log bn; or we can do it in a better way *)
      let bn = b.bblock_name in
      let i = List.nth bil 0 in
      let iloc = get_loc i in
      let iloc' = {iloc with loc_label = ""} in
      let addr' = obtain_addr iloc in
      let sn = build_stub b in
      let i1 = DoubleInstr (StackOP PUSH, Reg (CommonReg ECX), iloc, None) in
      let i2 = TripleInstr (CommonOP (Assign MOVL), Reg (CommonReg ECX), Label "index", iloc', None) in
      let i3 = TripleInstr (CommonOP (Assign MOVL),
                            Ptr (JmpTable_PLUS_S ("buf-4", CommonReg ECX, 4)),
                            Const (Normal addr'), iloc', None) in
      let i4 = DoubleInstr (ControlOP (Loop LOOP), Label sn, iloc', None) in
      let i5 = TripleInstr (CommonOP (Assign MOVL), Reg (CommonReg ECX),
                            Const (Normal 0x400000), iloc', None) in
      let i6 = TripleInstr (CommonOP (Assign MOVL), Label "index", Reg (CommonReg ECX),
                            {iloc' with loc_label = sn ^ ":"}, None) in
      let i7 = DoubleInstr (StackOP POP, Reg (CommonReg ECX), iloc', None) in
      let i' = set_loc i iloc' in
      self#insert_instrs i1 iloc acc
     |> self#insert_instrs i2 iloc
     |> self#insert_instrs i3 iloc
     |> self#insert_instrs i4 iloc
     |> self#insert_instrs i5 iloc
     |> self#insert_instrs i6 iloc
     |> self#insert_instrs i7 iloc
     |> self#sub_instrs i' iloc i 
     |> List.rev 

    (* This is a temporary method, which flush the logging
    data to the disk synchronizely. *)
    method update_current_bb_flush_disk acc b =
      let obtain_addr iloc =
        let a = iloc.loc_addr in
         a 
      in
      let build_stub b =
        let n = b.bblock_name in
        n ^ "_stub"
      in
      let bil = self#bb_instrs b in
      (* TODO: we can log bn; or we can do it in a better way *)
      let bn = b.bblock_name in
      let i = List.nth bil 0 in
      let iloc = get_loc i in
      let iloc' = {iloc with loc_label = ""} in
      let addr' = obtain_addr iloc in
      let sn = build_stub b in
      let i1 = DoubleInstr (StackOP PUSH, Reg (CommonReg ECX), iloc, None) in
      let i2 = TripleInstr (CommonOP (Assign MOVL), Reg (CommonReg ECX), Label "index", iloc', None) in
      let i3 = TripleInstr (CommonOP (Assign MOVL),
                            Ptr (JmpTable_PLUS_S ("buf-4", CommonReg ECX, 4)),
                            Const (Normal addr'), iloc', None) in
      let i4 = DoubleInstr (ControlOP (Loop LOOP), Label sn, iloc', None) in
      let i5 = DoubleInstr (StackOP PUSH, Reg (CommonReg EDX), iloc', None) in
      let i6 = DoubleInstr (StackOP PUSH, Reg (CommonReg EAX), iloc', None) in
      let i7 = DoubleInstr (ControlOP CALL, Label "logging_flush", iloc', None) in
      let i8 = DoubleInstr (StackOP POP, Reg (CommonReg EAX), iloc', None) in
      let i9 = DoubleInstr (StackOP POP, Reg (CommonReg EDX), iloc', None) in
      let i10 = TripleInstr (CommonOP (Assign MOVL), Reg (CommonReg ECX),
                            Const (Normal 0x400000), iloc', None) in
      let i11 = TripleInstr (CommonOP (Assign MOVL), Label "index", Reg (CommonReg ECX),
                            {iloc' with loc_label = sn ^ ":"}, None) in
      let i12 = DoubleInstr (StackOP POP, Reg (CommonReg ECX), iloc', None) in
      let i' = set_loc i iloc' in
      self#insert_instrs i1 iloc acc
     |> self#insert_instrs i2 iloc
     |> self#insert_instrs i3 iloc
     |>  self#insert_instrs i4 iloc
     |>  self#insert_instrs i5 iloc
     |>  self#insert_instrs i6 iloc
     |>  self#insert_instrs i7 iloc
     |>  self#insert_instrs i8 iloc
     |> self#insert_instrs i9 iloc
     |>  self#insert_instrs i10 iloc
     |>  self#insert_instrs i11 iloc
     |>  self#insert_instrs i12 iloc
     |>  self#sub_instrs i' iloc i 
     |> List.rev



    method update_current_bb_bak b =
      let obtain_addr iloc =
        let a = iloc.loc_addr in
         a land 0x00fffff
      in
      let build_stub b =
        let n = b.bblock_name in
        n ^ "_stub"
      in
      let bil = self#bb_instrs b in
      (* TODO: we can log bn; or we can do it in a better way *)
      let bn = b.bblock_name in
      let i = List.nth bil 0 in
      let iloc = get_loc i in
      let iloc' = {iloc with loc_label = ""} in
      let addr' = obtain_addr iloc in
      let sn = build_stub b in
      let i0 = DoubleInstr (StackOP PUSH, Reg (CommonReg EAX), iloc, None) in
      let i1 = DoubleInstr (StackOP PUSH, Reg (CommonReg EBX), iloc', None) in
      let i2 = SingleInstr (CommonOP (Assign LAHF), iloc', None) in
      let i3 = TripleInstr (CommonOP (Assign MOVL), Reg (CommonReg EBX), Label "index", iloc', None) in
      let i4 = TripleInstr (CommonOP (Assign MOVL),
                            Ptr (JmpTable_PLUS_S ("buf", CommonReg EBX, 4)),
                            Const (Normal addr'), iloc', None) in
      (* add $1, %eax   *)
      let i5 = TripleInstr (CommonOP (Assign LEA), Reg (CommonReg EBX), Ptr (BinOP_PLUS (CommonReg EBX, 1)), iloc', None) in
      let i6 = TripleInstr (CommonOP (Logic AND), Reg (CommonReg EBX), Const (Normal 0x3fffff), iloc', None) in
      let i7 = TripleInstr (CommonOP (Assign MOVL), Label "index", Reg (CommonReg EBX),
                            {iloc' with loc_label = sn ^ ":"}, None) in
      let i8 = SingleInstr (CommonOP (Assign SAHF), iloc', None) in
      let i9 = DoubleInstr (StackOP POP, Reg (CommonReg EBX), iloc', None) in
      let i10 = DoubleInstr (StackOP POP, Reg (CommonReg EAX), iloc', None) in
      let i' = set_loc i iloc' in
      self#insert_instrs i0 iloc;
      self#insert_instrs i1 iloc;
      self#insert_instrs i2 iloc;
      self#insert_instrs i3 iloc;
      self#insert_instrs i4 iloc;
      self#insert_instrs i5 iloc;
      self#insert_instrs i6 iloc;
      self#insert_instrs i7 iloc;
      self#insert_instrs i8 iloc;
      self#insert_instrs i9 iloc;
      self#insert_instrs i10 iloc;
      self#sub_instrs i' iloc i

    method print_bb_split b =
      print_string "reorder basic block : ";
      print_string b.bblock_name;
      print_string " ";
      print_string (dec_hex b.bblock_begin_loc.loc_addr);
      print_string " ";
      print_string (dec_hex b.bblock_end_loc.loc_addr);
      print_string "\n"

    method logging_bb bl acc =
      List.fold_left
        self#update_current_bb
        acc bl


      (**
       This is the instructions we use
      *)
    method bb_logging =
      let aux f bl acc =
        bl :: acc
      in
      let help bl acc =
        print_endline "done";
        self#logging_bb bl acc
      in
      print_endline "bb logging : ";
      print_int (Hashtbl.length fb_tbl);
      print_string "\n";
      let l = Hashtbl.fold aux fb_tbl [] in

      (*
      instrs_update <- List.flatten @@ List.fold_left help [] l;
       *)

      let module P = Parallel in

      instrs_update <- List.flatten @@
      P.pfold ~ncores: 12 ~concat: (@)  help l [];
      self#update_process


    method update_locs instrs =
      locs_update <- List.rev locs_update;
      let rec help il ll acc =
        match (il, ll) with
        | (ih::it, lh::lt) ->
           begin
             let lo = get_loc ih in
             if lo.loc_addr = lh.loc_addr then
               begin
                 let ih' = set_loc ih
                                   {loc_label = lo.loc_label^"\n"^lh.loc_label;
                                    loc_addr = lo.loc_addr;
                                    loc_visible = true;
                                   } in
                 help it lt (ih'::acc)
               end
             else
               (
                 help it ll (ih::acc)
               )
           end
        | (il', []) -> List.rev_append acc il'
        | ([], ll') -> failwith "error in update_locs" in
      help instrs locs_update []


    method update_process =
      instrs_update <-
        List.sort (
            fun (_,l1,_,_) (_,l2,_,_) ->
            l1.loc_addr - l2.loc_addr
          ) instrs_update;

      instrs <- self#update_instrs instrs;
      instrs_update <- []

    method bb_logging_process =
      self#bb_logging;
      instrs;


    method visit (il : instr list) : instr list =
      print_string "start bb merge \n";
      instrs <- il;
      self#bb_logging_process


    method set_fb_tbl (fb : (string, Type.bblock list) Hashtbl.t ) : unit =
      fb_tbl <- fb

  end
