c = ""

with open("final.s") as f:
    c = f.read()

# make sure this is no function name conflict.

foo = '''
logging_flush:
        pushl   %ebp
        movl    %esp, %ebp
        subl    $40, %esp
        movl    $0, -12(%ebp)
        movl    $.LC0, %edx
        movl    $.LC1, %eax
        movl    %edx, 4(%esp)
        movl    %eax, (%esp)
        call    fopen
        movl    %eax, -12(%ebp)
        movl    $buf, %eax
        movl    -12(%ebp), %edx
        movl    %edx, 12(%esp)
        movl    $0x400000, 8(%esp)
        movl    $4, 4(%esp)
        movl    %eax, (%esp)
        call    fwrite
        movl    -12(%ebp), %eax
        movl    %eax, (%esp)
        call    fclose
        leave
        ret
'''

# .LC0:
#        .string "wb"
# .LC1:
#        .string "bb_trace.bin"



# http://reverseengineering.stackexchange.com/questions/9365/dump-global-datas-to-disk-in-assembly-code

foo1 = '''
logging_flush:
    pushl   %ebp
    movl    %esp, %ebp
    andl    $-16, %esp
    subl    $32, %esp
    movl    $438, 8(%esp)
    movl    $0x1|0x40|0x400|0x8000, 4(%esp)
    movl    $.LC1, (%esp)
    call    open
    movl    %eax, 28(%esp)
    movl    $buf, %eax
    movl    $0x1000000, 8(%esp)
    movl    %eax, 4(%esp)
    movl    28(%esp), %eax
    movl    %eax, (%esp)
    call    write
    movl    28(%esp), %eax
    movl    %eax, (%esp)
    call    close
    leave
    ret
'''


# .LC1:
#        .string "bb_trace.bin"
c += foo1


with open("final.s", "w") as f:
    f.write(c)
