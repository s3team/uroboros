open Batteries
open Type
open Ail_parser
open Pp_print
(* open Reassemble *)
open Reassemble_symbol_get
open Cfg
open Cfi
open Cg
open Bb_logger

open Ail_utils

(* diversify plugins *)
open Func_inline_diversify
open Func_reorder_diversify
open Bb_branchfunc_diversify
open Bb_reorder_diversify
open Bb_split_diversify
open Bb_merge_diversify
open Bb_opaque_diversify
open Bb_flatten_diversify
open Instr_garbage_diversify
open Instr_replace_diversify


class ail =
object (self)
  val mutable funcs : func list = []
  val mutable secs: section list = []
  val mutable intrs: string list = []
  val mutable instrs_list: instr list = []
  val mutable datas: string list = []
  val mutable g_bss: (string*string) list = []

  method sections =
    let filelines = File.lines_of "sections.info"
    and help l =
      let items = Str.split (Str.regexp " +") l in
      let addr = int_of_string ("0x"^(List.nth items 1))
      and size = int_of_string ("0x"^(List.nth items 3))
      and secname = List.nth items 0 in
      secs <- {sec_name=secname; sec_begin_addr=addr;
               sec_size=size}::secs
    in
    Enum.iter help filelines

  method externfuncs =
    let filelines = File.lines_of "externfuncs.info"
    and help l =
      let items = Str.split (Str.regexp " +") l in
      let addr = int_of_string ("0x"^(List.nth items 0))
      and func = List.nth items 1 in
      funcs <- {func_name=func; func_begin_addr=addr; func_end_addr = 0;
                is_lib=true}::funcs
    in
    Enum.iter help filelines

  (* in stripped binary, any user functions' information has been stripped
   *  so slicing function class really does the job *)
  method userfuncs =
    let filelines = File.lines_of "userfuncs.info"
    and help l =
      if String.exists l "-0x" || String.exists l "+0x" then
        ()
      else
        begin
          let items = Str.split (Str.regexp " +") l in
          let addr = int_of_string ("0x"^(List.nth items 0))
          and funname = List.nth items 1 in
          let len = String.length funname in
          let funname' = String.sub funname 1 (len-3) in
          funcs <- {func_name=funname'; func_begin_addr=addr; func_end_addr = 0;
                    is_lib=false}::funcs
        end
    in
    Enum.iter help filelines


  method get_userfuncs =
    List.filter (fun f -> f.is_lib=false) funcs

  method externdatas =
    let filelines = File.lines_of "externdatas.info"
    and help l =
      let data = String.trim l in
      datas <- data::datas
    in
    Enum.iter help filelines

  method global_bss =
    let filelines = File.lines_of "globalbss.info"
    and help l =
      let items = Str.split (Str.regexp " +") l in
      let t = List.nth items 0 in
      let addr = String.sub t 1 ((String.length t)-1) in
      let addr' = String.uppercase addr
      and n = String.trim (List.nth items 1) in
      g_bss <- (addr', n)::g_bss
    in
    Enum.iter help filelines

  method ail_dump =
    (*currently we just dump the extern function info *)
    let check_sym_func f =
      try
        let s = Char.escaped(f.func_name.[0])^Char.escaped(f.func_name.[1]) in
        s <> "__"
      with
      | _ -> false in
    let oc = open_out_gen [Open_append; Open_creat] 0o666 "final.s" in
    (List.filter (fun f -> f.is_lib) funcs
     |> List.filter check_sym_func
     |> List.iter (fun l -> Printf.fprintf oc "extern %s\n" l.func_name));
    close_out oc

  method ehframe_dump =
    Sys.command("cat eh_frame.data >> final.s")

  method excpt_tbl_dump =
    Sys.command("cat gcc_exception_table.data >> final.s")

  method post_process =
    Sys.command("python post_process.py");
    Sys.command("python post_process_lib.py");
    ()
  (*
          self#ehframe_dump;
          self#excpt_tbl_dump;
   *)

  method pre_process =
    let  _ = Sys.command("python pre_process.py") in
    ()


  (*
   * unsolved bugs exist when updating current instrProcess with
   * div plugins, so let's fork this function and rewrite the copied
   * version with previous workable code in div git branch
   *)

  (* TODO: merge instrProcess with instrProcess_2 *)
  method instrProcess =
    let re_ass_plugin = new reassemble
    and cfg_plugin = new cfg
    and cg_plugin = new cg
    and bb_spt_div = new bb_split_diversify
    and logger = new logger
    and bb_meg_div = new bb_merge_diversify
    and func_rod_div = new func_reorder_diversify
    and bb_rod_div = new bb_reorder_diversify
    and ins_rpl_div = new instr_replace_diversify in
    (*
    and func_inline_div = new func_inline_diversify
    and bb_bfn_div = new bb_branchfunc_diversify
    and bb_fln_div = new bb_flatten_diversify in
    and ins_gar_div = new instr_garbage_diversify in
    and bb_opq_div = new bb_opaque_diversify
    and bb_spt_div = new bb_split_diversify
    and bb_opq_div = new bb_opaque_diversify in
    and bb_fln_div = new bb_flatten_diversify in
    and bb_spt_div = new bb_split_diversify
    *)
    let () = self#pre_process in
    let filelines = File.lines_of "instrs.info" in
    let () = Enum.iter (fun l -> intrs<- l::intrs) filelines in
    intrs <- List.rev intrs;
    let ail_parser = new ailParser in
    ail_parser#set_funcs(funcs);
    ail_parser#set_secs(secs);
    ail_parser#processInstrs(intrs);
    (* two processes have been done when passing funcs list into ail_parser
     *
     *  1. collect all the extern functions identified during parsing process
     *  2. function slicing on stripped binary, supporting CFI specified CG generation
     *)
    funcs <- ail_parser#get_funcs;
    cg_plugin#set_funcs funcs;
    cfg_plugin#set_funcs funcs;
    let u_funcs = self#get_userfuncs in
      print_endline "user defined func number ";
      print_int (List.length u_funcs);
      print_string "\n";
    (ail_parser#get_instrs
     |> cg_plugin#visit
     |> re_ass_plugin#visit_type_infer_analysis []
     |> re_ass_plugin#share_lib_processing
     |> re_ass_plugin#adjust_loclabel
     |> (fun ll -> (instrs_list <- ll)));

    re_ass_plugin#reassemble_dump u_funcs;
    (re_ass_plugin#adjust_jmpref instrs_list
     |> re_ass_plugin#add_func_label u_funcs
     |> cfg_plugin#visit (* build CFG *)
     |> (fun ll -> (instrs_list <- ll)));

    let fbl = cfg_plugin#get_fbl in
    let bbl = cfg_plugin#get_bbl in
    let cfg_t = cfg_plugin#get_cfg_table instrs_list in
    bb_spt_div#set_fb_tbl fbl;
    logger#set_fb_tbl fbl;
    bb_meg_div#set_fb_tbl fbl;
    bb_meg_div#set_cfg_tbl cfg_t;
    func_rod_div#set_funclist u_funcs;
    bb_rod_div#set_fb_tbl fbl;
    (*
    func_inline_div#set_funclist u_funcs;
    bb_bfn_div#set_funclist u_funcs;
    bb_fln_div#set_cfg_tbl cfg_t;
    bb_fln_div#set_fb_tbl fbl;
    bb_fln_div#set_funclist u_funcs;
    ins_gar_div#set_fb_tbl fbl;
    ins_gar_div#set_fb_tbl fbl;
    bb_opq_div#set_fb_tbl fbl;
     *)
    cg_plugin#get_cg_table;
    let instrsl = re_ass_plugin#add_bblock_label bbl instrs_list in

   (*
   let c = read_file "count.txt" in
   let c' = List.nth c 0 in
   let c1 = String.strip c' in
   let cn = int_of_string c1 in
   *)

	(*
   print_endline "start trimming";
   let open Bb_trimmer in
   let module T = Trimmer in
   let instrsl' = T.trim bbl instrsl in
	*)
   (*
   let instrsl' = instrsl in
   let instrsl' = logger#visit instrsl in
  *)

   let open Bb_counting in
   let module BC = BB_counting in
   let instrsl' = BC.instrument instrsl fbl bbl in

(*
   let open Trace_profiling in
   let module TP = Trace_profiling in
   let instrsl' = TP.instrument instrsl fbl bbl in
*)

	(*
   let open Func_counting in
   let module FC = Func_counting in
   let instrsl' = FC.instrument instrsl fbl bbl in
	*)


(*
   let open Instr_sandbox in
   let module S = Sandbox in
   let instrsl' = S.instrument instrsl in
*)

    (*
   let instrsl' = instrsl in
     *)

     (* diversify plugin begin *)

     (* 1: basic block reorder diversify *)
     (* |> bb_rod_div#visit *)
     (* 2: basic block split diversify *)
     (* |> bb_spt_div#visit *)
     (* 3: instruction garbage insertion diversify *)
     (* |> ins_gar_div#visit *)
     (* 4: instruction replace diversify *)
     (* |> ins_rpl_div#visit *)
     (* 5: function reorder diversify *)
     (* |> func_rod_div#visit *)
     (* 6: basic block opaque predicate diversify *)
     (* |> bb_opq_div#visit *)
     (* 7: function inline diversify *)
     (* |> func_inline_div#visit  *)
     (* 8: basic block merge diversify *)
     (* |> bb_meg_div#visit *)
     (* 9: basic block flatten diversify *)
    (*  |> bb_fln_div#visit *)
     (* 10: control flow branch function diversify *)
     (* |> bb_bfn_div#visit *)

     (* diversify plugin end *)

     (* the unify_loc function would remove all redundant labels *)
     ( re_ass_plugin#unify_loc instrsl'
    |> pp_print_list
     (* adjust references from .text section into .bss section, usually it is
      * the addresses of libc functions
      * FIXME:  it might not be the most suitable way, but right now it works fine.
      * *)
    |> re_ass_plugin#adjust_globallabel g_bss
    |> pp_print_file);
    (* we don't need this as gcc can automatically link the stdlib*)
    (* self#ail_dump; *)
    self#post_process

  method instrProcess_2 f =
    let open Disassemble_process in
    let open Analysis_process in
    let module D = Disam in
    let module A = Analysis in
    let () = self#pre_process in

    let (il, fl, re) = D.disassemble f funcs secs in

	print_endline "3: analysis";

    let (fbl, bbl, cfg_t, cg, il', re) = A.analyze_one il fl re in

    (*
    let open Bb_counting in
    let module BC = BB_counting in
    let il' = BC.instrument il fbl bbl in
    *)

    (*
    let open Mem_write in
    let module MW = Mem_write in
    let il' = MW.process il in
     *)


	print_endline "5: post processing";
    A.post_analyze il' re;

    self#post_process

  (* this function is temporarily developed for gcc/gobmk usage *)
      (*
  method instrProcess_simplified =
    let re_ass_plugin = new reassemble
    and dis_valid = new dis_validator
    and cfg_plugin = new cfg
    and cg_plugin = new cg
    and bb_rod_div = new bb_reorder_diversify
    and bb_spt_div = new bb_split_diversify
    and ins_gar_div = new instr_garbage_diversify
    and ins_rpl_div = new instr_replace_diversify in
    let () = self#pre_process in
    let filelines = File.lines_of "instrs.info" in
    let () = Enum.iter (fun l -> intrs<- l::intrs) filelines in
    intrs <- List.rev intrs;
    let ail_parser = new ailParser in
    ail_parser#set_funcs(funcs);
	ail_parser#set_secs(secs);
    ail_parser#processInstrs(intrs);
    funcs <- ail_parser#get_funcs;

    let u_funcs = self#get_userfuncs in
    let instrlist = ail_parser#get_instrs in



	print_string "2: disassembly validates --> ";
	print_string "no disassembly error detects\n";
	print_newline;


    ( re_ass_plugin#visit_type_infer_analysis [] instrlist
      |> re_ass_plugin#share_lib_processing
      |> re_ass_plugin#adjust_loclabel
      |> (fun ll -> (instrs_list <- ll)));


    re_ass_plugin#reassemble_dump u_funcs;

    (re_ass_plugin#adjust_jmpref instrs_list
     |> re_ass_plugin#add_func_label u_funcs
     |> (fun ll -> (instrs_list <- ll)));

	print_string "4: dump new assembly code, data and meta info to final.s \n";

    (re_ass_plugin#add_bblock_label [] instrs_list
     |> re_ass_plugin#unify_loc
     |> pp_print_list
     |> re_ass_plugin#adjust_globallabel g_bss
     |> pp_print_file);

	print_string "5: post processing:\n";
    self#post_process
*)

end
